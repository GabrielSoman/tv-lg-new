#!/usr/bin/env python3
"""Gera os icones e o splash do app a partir de codigo (sem depender de arquivos externos)."""
import math
from PIL import Image, ImageDraw, ImageFilter

OUT = "app/assets"
BG = (7, 8, 11)
A1 = (124, 92, 255)   # roxo
A2 = (78, 168, 255)   # azul


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def diagonal_gradient(size, c1, c2):
    w, h = size
    img = Image.new("RGB", size)
    px = img.load()
    for y in range(h):
        for x in range(w):
            t = (x / max(w - 1, 1) * 0.55) + (y / max(h - 1, 1) * 0.45)
            px[x, y] = lerp(c1, c2, min(1.0, t))
    return img


def rounded_mask(size, radius, ss=4):
    big = (size[0] * ss, size[1] * ss)
    m = Image.new("L", big, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, big[0] - 1, big[1] - 1],
                                        radius=radius * ss, fill=255)
    return m.resize(size, Image.LANCZOS)


def play_mark(size, ss=4):
    """Triangulo de play com cantos arredondados, centralizado."""
    big = (size[0] * ss, size[1] * ss)
    m = Image.new("L", big, 0)
    d = ImageDraw.Draw(m)
    w, h = big
    cx, cy = w * 0.53, h * 0.5
    r = w * 0.26
    pts = []
    for k in range(3):
        ang = math.radians(-90 + k * 120 + 90)
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    d.polygon(pts, fill=255)
    m = m.filter(ImageFilter.GaussianBlur(w * 0.012))
    m = m.point(lambda v: 255 if v > 128 else 0)
    return m.resize(size, Image.LANCZOS)


def make_icon(size, radius_ratio=0.22):
    s = (size, size)
    grad = diagonal_gradient(s, A1, A2)
    icon = Image.new("RGBA", s, (0, 0, 0, 0))
    icon.paste(grad, (0, 0), rounded_mask(s, int(size * radius_ratio)))

    # sombra suave sob o triangulo, so para descolar do fundo
    shadow = play_mark(s).filter(ImageFilter.GaussianBlur(size * 0.03))
    shadow = shadow.point(lambda v: int(v * 0.30))
    icon.paste(Image.new("RGBA", s, (10, 6, 40, 255)), (0, int(size * 0.02)), shadow)

    icon.paste(Image.new("RGBA", s, (255, 255, 255, 255)), (0, 0), play_mark(s))
    return icon


def make_splash(w=1920, h=1080):
    img = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(img, "RGBA")
    # brilho radial suave no centro-esquerda
    glow = Image.new("L", (w // 4, h // 4), 0)
    gd = ImageDraw.Draw(glow)
    gd.ellipse([w // 16, h // 16, w // 4 - w // 16, h // 4 - h // 16], fill=90)
    glow = glow.filter(ImageFilter.GaussianBlur(40)).resize((w, h), Image.LANCZOS)
    img.paste(Image.new("RGB", (w, h), A1), (0, 0), glow)

    mark = make_icon(300, radius_ratio=0.24)
    img.paste(mark, ((w - 300) // 2, (h - 300) // 2 - 40), mark)
    return img


if __name__ == "__main__":
    make_icon(80).save(f"{OUT}/icon.png")
    make_icon(130).save(f"{OUT}/largeIcon.png")
    make_splash().save(f"{OUT}/splash.png")
    print("assets gerados em", OUT)
