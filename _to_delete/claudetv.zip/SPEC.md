# Nebula — Especificação Técnica

> Documento de projeto. Escrito depois de auditar o código que está rodando,
> medir os sintomas relatados na TV real e pesquisar como apps de TV sérios
> resolvem esses mesmos problemas. Tudo que está aqui é decisão, não sugestão:
> o código deve seguir este documento, e quando divergir, o documento é que
> está errado e deve ser corrigido primeiro.

**Alvo:** LG 50NANO80TSA · webOS TV 24 · Chromium 108 · app renderizado em
1920×1080 · navegação exclusiva por controle remoto.

---

## 1. O que está errado hoje

Dois sintomas foram relatados. Nenhum dos dois é um bug pontual: os dois são
consequência direta de uma decisão de arquitetura que precisa ser desfeita.

### 1.1 "O app inteiro se comporta como uma coluna só"

Relato exato: *"se eu desço todas as pastas de filmes, chega uma hora que
continua descendo mas para de ser visível na tela, e se continuo descendo ele
simplesmente cai pra parte de conteúdo — não por eu ir para o lado, ele de
descer cai para a coluna do lado. Isso não tem lógica nenhuma."*

**Causa raiz: não existe conceito de região no código.** A decisão de foco é
uma linha só (`nav.js:191`):

```js
stepInContainer(current, dir) || geometric(current, dir)
```

O `||` é o problema inteiro. Quando o movimento dentro do contêiner falha —
inclusive quando falha *porque chegou na borda, que é o comportamento correto* —
o código trata isso como "procure em qualquer lugar da tela". Aí `geometric()`
varre **todos** os focáveis do documento e aceita qualquer um no semiplano da
direção. Chegando no fim da coluna de categorias, o único candidato "abaixo" é
um card da grade à direita. Ele vence por falta de concorrente. O foco vaza.

Não há nada no código que possa retornar "não existe destino nessa direção".
Por isso o app se comporta como uma sopa geométrica única: as colunas são
visuais, não estruturais.

O atributo `data-nav-group="rail"` existe no HTML (`dom.js:42`) e **nunca é
lido em lugar nenhum** — resto de uma intenção de regiões que nunca foi
implementada.

### 1.2 "Continua descendo e para de ser visível"

**Causa raiz: cálculo de limite de rolagem errado** (`nav.js:71`):

```js
var minY = Math.min(0, vp.clientHeight - sc.scrollHeight - 8);
```

`vp` é `.cats`, que tem `padding: 3.4rem 1.2rem 3rem 4rem` **e** um irmão
anterior (`.cats-head`). O `clientHeight` inclui os paddings, e a fórmula
ignora tanto os paddings quanto a altura do cabeçalho. Com 1rem ≈ 17,1px,
são **~145px de rolagem que nunca acontecem** — cerca de três categorias que
continuam recebendo foco (o `offsetParent` delas não é nulo) mas ficam abaixo
da borda, recortadas pelo `overflow:hidden`.

Piora com um segundo erro: a margem inferior desejada é `vr.height * 0.26`,
ou seja ~281px num viewport de 1080px. O `clamp` nunca concede isso, o `dy`
satura em silêncio e o item some.

E há um terceiro: `ensureVisible` mede com `getBoundingClientRect` (valores
**visuais**, no meio de uma transição de 120ms) mas guarda o deslocamento em
`data-off-y` (valor **final**). Com o auto-repeat do controle a ~100-150ms,
cada tecla mede uma posição intermediária e soma sobre o alvo. O erro acumula.

A tela inicial rola certo porque o viewport dela (`.screen-scroll`) não tem
padding. Isso confirma o diagnóstico: a fórmula só quebra onde o viewport tem
padding ou irmãos.

### 1.3 A queda de frames

Relato: *"queda de frame brutal ao navegar pelos conteúdos; inicia rápido e
ao dar play vai muito liso."*

Esse "ao dar play vai liso" é a pista mais valiosa do diagnóstico. Quando o
player abre, `#player-layer` é `position:fixed; inset:0; background:#000` —
opaco, cobrindo tudo. O Chromium faz *occlusion culling* e descarta toda a
pilha de fundo. **O que fica liso é exatamente a tela sem os efeitos.**

Os cinco culpados, em ordem:

| # | Culpado | Custo real |
|---|---|---|
| 1 | `#ambient` — fundo desfocado que segue o item em foco | `blur(30,9px)` + `saturate` sobre uma caixa que, com `scale(2.7)`, ocupa **2,33 Mpx (112% do frame)**. Disparado a cada 260ms de navegação, com fade de 1,1s que se sobrepõe às teclas seguintes. E a imagem de origem é o **pôster original** (até 1000×1500) decodificado inteiro para depois ser reduzido. |
| 2 | Transição de `box-shadow` no card em foco | `box-shadow` **não é compositável**: transicioná-lo repinta na main thread a cada quadro. São três sombras empilhadas, a maior com blur de 58px → ~148 kpx de retângulo borrado por quadro, em **dois** elementos (o que perde e o que ganha foco) → **~4,7 Mpx de sombra repintada por um único toque no direcional**. |
| 3 | `will-change: transform` permanente em 4 seletores | Nunca é removido. Na home são 9+ camadas de composição permanentes; uma `.row-track` com 40 cards mede ~8570px de largura ≈ 12,7 MB de textura. Somando tudo: **60-100 MB** contra um orçamento de GPU de TV que costuma ficar em 64-128 MB → despejo de tiles e re-raster em cascata. É a assinatura exata de "queda brutal ao navegar". |
| 4 | Pilha de gradientes de tela cheia | `#ambient-veil` (2 radiais + 1 linear = 2,07 Mpx) + `.billboard::after` (1,38 Mpx). Qualquer tile invalidado re-blenda 4+ camadas alfa. |
| 5 | `nav.js` — O(n) e *layout thrashing* por tecla | Até **~290 `getBoundingClientRect` + 290 `offsetParent`** por movimento. Pior: `ensureVisible` lê `rect`/`scrollWidth` **depois** de escrever `style.transform` em scrollers aninhados → *forced synchronous reflow* garantido. |

Menções que agravam continuamente: o Ken Burns do billboard (`transform 9s
linear` num elemento de 1920×720 com `background-image`, reiniciado a cada 9s)
mantém o compositor **sempre ativo** na home; e os esqueletos animam
`background-position`, que não é compositável, em 14 elementos.

### 1.4 Defeitos adicionais encontrados na auditoria

Não relatados pelo usuário, mas reais e todos consequência da mesma falta de
estrutura:

1. O billboard reconstrói o DOM a cada 9s e **destrói o elemento em foco**,
   deixando `current` órfão; a próxima seta cai no primeiro item do menu.
2. O billboard **rouba** o foco de quem estava no menu.
3. Sair da home antes das promessas resolverem deixa timers rodando sobre
   telas removidas.
4. `.seasons` e `.row-btns` têm eixo `x` mas `flex-wrap: wrap`: a ordem do DOM
   deixa de bater com a ordem visual e "direita" volta para a esquerda embaixo.
5. `BACKSPACE` está mapeado como Voltar: apagar caractere na busca navega para
   trás, e o `preventDefault` impede a edição do texto.
6. A proteção de digitação cobre só ←/→; ↑/↓ tiram o foco do campo com o
   teclado virtual aberto.
7. `App.back()` não restaura foco nem rolagem: volta-se sempre para o foco
   padrão da tela.
8. Qualquer perda de foco cai em `focusFirst()`, cujo primeiro elemento é
   sempre o menu — teleporte.
9. Entrar no menu anima a largura de 6rem→16rem: **layout a cada quadro por
   300ms**, mais uma sombra de 86px de blur num elemento de 1080px de altura.
10. Elementos recortados por `overflow:hidden` continuam focáveis, porque a
    única verificação de visibilidade é `offsetParent !== null`.

---

## 2. Princípios

Estes princípios são a régua. Toda decisão de implementação deve poder ser
justificada por um deles.

**P1 — Regiões antes de geometria.** A tela é uma árvore de regiões declaradas,
não um conjunto de retângulos. A geometria só desempata *dentro* de uma região.

**P2 — A borda é uma resposta válida.** "Não há para onde ir" é um resultado
legítimo e deve parar o foco, não procurar em outro lugar. Vazar de região só
acontece quando a região declara explicitamente um vizinho naquela direção.
É o que a spec CSS Spatial Navigation e o LRUD da BBC fazem: sem candidato, a
busca sobe na árvore de forma controlada — e o *wrapping* é sempre opt-in.

**P3 — Só `transform` e `opacity` animam.** Qualquer outra propriedade animada
é um bug de performance até prova em contrário. Isso vale especialmente para
`box-shadow`, `background-position`, `width` e `filter`.

**P4 — Nenhum filtro em tempo de execução.** Zero `filter: blur()`, zero
`backdrop-filter`. Efeito de desfoque se obtém com imagem já reduzida e o
upscale do próprio navegador, que é gratuito.

**P5 — Camadas são caras e contadas.** `will-change` só no elemento que está
animando naquele instante, e removido depois. Nunca em card de catálogo.

**P6 — Ler tudo, depois escrever tudo.** Nenhuma leitura de layout depois de
uma escrita de estilo no mesmo quadro. Medições em cache, invalidadas por
evento explícito.

**P7 — O que não está na tela não existe.** Listas longas são virtualizadas.
Elemento fora do recorte do viewport não é focável.

**P8 — Previsível vence bonito.** Se um efeito visual custa previsibilidade de
navegação ou fluidez, o efeito sai. A sensação de qualidade numa TV vem de
60fps constantes, não de sombras.

---

## 3. Modelo de navegação

Substitui `nav.js` inteiro. É a peça central da reescrita.

### 3.1 Estrutura

A tela é uma **árvore de regiões**. Cada região é declarada no DOM e registrada
no motor:

```html
<div data-region="cats" data-axis="y" data-neighbors='{"left":"rail","right":"grid"}'>
```

| Propriedade | Valores | Significado |
|---|---|---|
| `id` | string | Nome da região, único na tela |
| `axis` | `x` · `y` · `grid` | Como o foco anda **dentro** da região |
| `neighbors` | `{dir: regiãoId}` | Para onde o foco vai ao sair por aquela borda. **Direção ausente = o foco para.** |
| `wrap` | `false` (padrão) | Dar a volta no fim. Opt-in, por região e por eixo |
| `enter` | `first` · `last-focused` · seletor | Qual item recebe o foco ao entrar na região |
| `virtual` | boolean | A região virtualiza seus filhos |

### 3.2 Algoritmo

```
mover(direção):
  região = regiãoDe(focoAtual)
  alvo = próximoDentroDaRegião(região, focoAtual, direção)
  se alvo:            focar(alvo); fim
  vizinho = região.neighbors[direção]
  se vizinho:         focar(entradaDe(vizinho)); fim
  parar                                  // ← P2: isto é sucesso, não falha
```

Não existe fallback global. Não existe varredura do documento.

**Dentro da região**, por eixo:

- `x` / `y` — índice ±1 na lista de filhos focáveis **visíveis**. Fora do
  intervalo → `null`.
- `grid` — o motor conhece as colunas por linha (calculadas uma vez por
  layout, em cache). ←/→ andam na linha e param nas pontas. ↑/↓ vão para a
  linha vizinha, escolhendo o item de maior **sobreposição de projeção** no
  eixo X — não o de menor distância euclidiana. Sem sobreposição mínima de
  30%, não há candidato.

Essa função de custo é a da spec CSS Spatial Navigation: alinhamento e
sobreposição **subtraem** custo. É o que faz o foco descer em coluna numa grade
em vez de pular na diagonal.

### 3.3 Regiões por tela

| Tela | Região | ← | → | ↑ | ↓ |
|---|---|---|---|---|---|
| todas | `rail` | parar | região principal, no **último foco memorizado** | parar | parar |
| home | `hero` | `rail` | parar | parar | `rows` |
| home | `rows` (fileiras) | `rail` no 1º card | parar no último | fileira acima / `hero` | fileira abaixo, parar na última |
| browse | `cats` | `rail` | `grid` | parar | **parar** |
| browse | `grid` | `cats` na 1ª coluna | parar | parar | parar (pagina) |
| detalhe | `actions` | `rail` | parar | parar | `seasons` ou `episodes` |
| detalhe | `seasons` | `rail` | parar | `actions` | `episodes` |
| detalhe | `episodes` | `rail` | parar | `seasons` | parar |
| busca | `field` | cursor | cursor | parar | `results` |
| busca | `results` | `rail` na 1ª coluna | parar | `field` | parar |
| modais | escopo fechado | — | — | — | — |

### 3.4 Regras adicionais

- **Memória por região.** Cada região guarda o último filho focado. Voltar ao
  menu e entrar de novo restaura onde você estava.
- **Visibilidade real.** Focável = dentro do retângulo de conteúdo do viewport
  recortante, não apenas `offsetParent !== null`.
- **Elemento que some.** Se o focado é removido do DOM, o foco vai para o
  vizinho mais próximo na mesma região; se a região sumiu, para a entrada da
  região pai. Nunca para o menu.
- **Throttle de teclas.** Auto-repeat do controle chega a 10-15 eventos/s.
  O motor processa no máximo um movimento por quadro (`requestAnimationFrame`)
  e descarta o excedente.
- **Digitação.** Com `<input>` focado, ←/→/Backspace pertencem ao campo. Só
  ↑/↓ e Voltar saem. O teste é sobre `document.activeElement`.
- **Voltar (461).** Detalhe → lista → home → diálogo de saída. Cada nível
  restaura foco e rolagem de onde saiu. `BACKSPACE` deixa de ser Voltar.

### 3.5 Rolagem

Reescrita, com o cálculo correto:

```
limiteMínimo = alturaDoConteúdoDoViewport − alturaDoScroller
alturaDoConteúdoDoViewport = clientHeight − paddingTop − paddingBottom
                             − altura dos irmãos que ocupam espaço
```

Mais três correções:

1. Margens de rolagem em **pixels absolutos** (120px topo, 160px base), não
   em percentual do viewport.
2. Posição-alvo calculada a partir do **deslocamento armazenado**, nunca de
   `getBoundingClientRect` durante uma transição.
3. Todas as leituras de layout de um movimento acontecem antes de qualquer
   escrita, e a escrita é aplicada uma vez, dentro de um `rAF`.

---

## 4. Orçamento de performance

Regras duras. Violá-las é regressão.

### Proibido

| O quê | Por quê |
|---|---|
| `filter: blur()` e `backdrop-filter` | Paint com blur é comprovadamente o mais caro; em TV é proibitivo |
| `transition`/`animation` em `box-shadow` | Não compositável → repaint na main thread por quadro |
| `transition: all` | Anima o que você não sabe que está animando |
| `animation` em `background-position` | Não compositável |
| `will-change` estático em qualquer elemento de catálogo | Explosão de camadas → estouro de memória de vídeo |
| Animar `width`/`height`/`top`/`left` | Layout por quadro |
| `-webkit-text-stroke` animado | Path-stroking sem cache de glifo |
| Ler layout depois de escrever estilo no mesmo quadro | Reflow síncrono forçado |

### Permitido e como

| Efeito desejado | Implementação barata |
|---|---|
| Fundo ambiente colorido | **Decisão tomada: removido.** Fundo escuro sólido. Era o culpado nº 1 da queda de frames e você optou por tirar de vez |
| Foco no card | `transform: scale()` + `outline` sólido de 4px + uma sombra **estática** (não transicionada) |
| Realce/glow | Elemento irmão com `opacity` transicionada, sombra pré-renderizada e fixa |
| Rolagem de fileira | `transform: translate3d()` no track, `will-change` adicionado no início do movimento e **removido** no `transitionend` |
| Esqueleto de carregamento | `opacity` pulsando entre 0.4 e 0.8. Nada de gradiente móvel |
| Entrada de tela | `opacity` apenas. Sem `transform` de tela inteira |

### Orçamentos

| Métrica | Alvo |
|---|---|
| Quadro durante navegação | ≤ 16ms; nenhum acima de 33ms |
| Nós DOM por tela | ≤ 1200 |
| Cards renderizados por vez | ≤ 40 (virtualização acima disso) |
| Camadas compostas simultâneas | ≤ 4 |
| `getBoundingClientRect` por tecla | ≤ 8 |
| Imagem de capa em memória | ≤ 200×300, servida ou reduzida na ingestão |
| Abertura do app até catálogo visível | ≤ 4s com cache, ≤ 8s sem |

> **Nota honesta:** não existe número oficial publicado pela LG ou pela Samsung
> para orçamento de nós DOM, camadas de composição ou memória de vídeo em TV.
> Os valores acima são metas de engenharia derivadas dos sintomas medidos e da
> prática de projetos como o Jellyfin webOS — e devem ser **verificados no
> aparelho** com `npm run log`, não tratados como verdade absoluta.

---

## 5. Sistema visual

### 5.1 Métricas de 10 pés

Convertidas para CSS px numa tela de 1920×1080 a partir das diretrizes da
Microsoft (que publica mínimos numéricos) e do Android TV:

| Item | Valor |
|---|---|
| Safe area lateral | 96px |
| Safe area vertical | 54px |
| Corpo de texto | ≥ 30px |
| Texto secundário | ≥ 24px |
| Altura mínima de alvo focável | ≥ 64px |
| Profundidade de navegação | ≤ 6 movimentos de borda a borda |
| Faixa de cor | RGB 16–235; **sem preto puro nem branco puro** |

O `#07080B` atual e o `#F2F4F8` já respeitam a faixa. Manter.

### 5.2 Foco

O foco precisa ser legível a 3 metros, de canto de olho. Três sinais
simultâneos, todos baratos:

1. `transform: scale(1.06)` — compositável.
2. `outline: 4px solid #FFFFFF` — sem blur, sem transição.
3. Escurecimento dos vizinhos via `opacity` do container, não do item.

Duração da transição: **120ms**. Acima disso o auto-repeat do controle
atropela a animação anterior.

### 5.3 Estrutura da home

O padrão da própria LG para webOS — e o que os apps grandes seguem — é
navegação global persistente à esquerda, um destaque no topo, e fileiras
temáticas em rolagem vertical. Manter essa estrutura, com duas mudanças:

- O menu lateral **não anima largura**. Ele é sempre estreito e mostra rótulo
  por `opacity`, ou é sempre largo. Animar `width` é layout por quadro.
- O destaque do topo **não tem Ken Burns**. Troca com `opacity` apenas, e a
  troca automática pausa enquanto o foco está dentro dele.

Fileiras para descoberta; grade só para busca e para uma categoria única, e
sempre virtualizada.

---

## 6. Arquitetura de dados

Reescrita com os números reais do provedor, medidos em
`relatorio-lista.md`. A conclusão muda tudo: **a API responde, e é pequena.**

### 6.1 O que mudou

O app roda hoje em modo M3U e baixa **81,5 MB** com 290.124 itens, parseia na
thread da interface e tenta guardar tudo num blob de IndexedDB. Isso sozinho
explica boa parte do peso.

Só que a API **funciona** — o que enganava é que o painel devolve HTTP 200 com
corpo vazio quando o cliente manda `Accept-Encoding: gzip`. Sem pedir
compressão, ou por POST, ela responde normal. E os tamanhos são estes:

| chamada | resposta | cobertura |
|---|---|---|
| `get_live_categories` | 4 kB | 50 categorias |
| `get_vod_categories` | 4 kB | 50 categorias |
| `get_series_categories` | 2 kB | 29 categorias |
| `get_live_streams` (**tudo**) | **820 kB** | 2.846 canais |
| `get_vod_streams` (1 categoria) | 85 kB | 264 filmes |
| `get_series` (1 categoria) | 913 kB | 1.343 séries |
| `get_series_info` | 39 kB | 2 temporadas, 16 episódios |
| `get_short_epg` | 1 kB | 3 programas |

**Os 2.846 canais inteiros cabem em 820 kB.** É 1% da lista M3U. Toda a
estratégia de "ingestão em Worker com escrita incremental" que eu tinha
proposto some: não é mais necessária.

E a API devolve `Access-Control-Allow-Origin: *` — então **a TV fala direto,
sem proxy**. O proxy continua no projeto só como reserva.

### 6.2 Regras

1. **Nunca mais baixar a lista M3U.** Modo M3U vira apenas fallback para o
   caso de a API sumir.
2. **Todas as requisições da API por POST**, com `username`, `password` e
   `action` no corpo. Nunca mandar `Accept-Encoding`.
3. **Canais: carregar tudo de uma vez** (820 kB) na abertura, guardar em
   IndexedDB. É o que viabiliza busca instantânea, ordenação por hábito,
   zapping por número e o agrupamento de qualidade.
4. **Filmes e séries: por categoria, sob demanda**, com cache por categoria e
   validade de 6 horas. `get_series` de uma categoria grande chega a 900 kB —
   carregar e guardar, mas nunca todas as categorias de uma vez.
5. **Detalhe sob demanda:** `get_vod_info` e `get_series_info` só quando a
   tela de detalhe abre. São 1 kB e 39 kB.
6. **IndexedDB por chave granular** — `cat:live`, `items:movie:12`,
   `series:8891` — nunca um blob único.
7. **Uma conexão por vez.** A conta tem `max_connections: 1`. Ver 6.4.

### 6.3 O que a API entrega e o app ignorava

Levantado nos campos reais:

- **`tmdb_id` está presente** nos filmes (e até nos episódios, em
  `episode.info.tmdb_id`), junto de `tmdb_url`. Relacionados via TMDB deixam
  de ser hipótese.
- **`backdrop_path`** existe em filmes **e em séries** — é a imagem certa para
  o hero, que hoje usa o pôster retrato esticado.
- `cover_big`, `country`, `age`, `mpaa_rating`, `actors`, `description`,
  `duration_secs`, `bitrate` — tudo disponível para a tela de detalhe.
- **`get_series` já traz `plot`, `cast`, `director`, `genre`, `rating`,
  `backdrop_path` e `youtube_trailer`** na própria listagem. A grade de séries
  não precisa de chamada extra.
- **Episódios trazem `season`, `episode_num` e `info.duration_secs`** — e no
  teste vieram **16 de 16 com duração**. O fim de episódio passa a ser
  detectável com precisão, e a fila do próximo episódio vira trivial.
- `tv_archive` e `tv_archive_duration` existem nos canais, mas estão **zerados
  em todos os 2.846** — o plano não tem catch-up. Recurso descartado.

### 6.4 A restrição que molda o player

`max_connections: 1` significa **uma transmissão por vez**. Consequências que
viram requisito:

- **Nada de pré-carregar** o próximo episódio ou a variante de qualidade. O
  que eu tinha escrito sobre isso na spec de experiência está cancelado.
- Toda troca é **fechar e só então abrir**. O corte de 1 a 3 segundos é
  inevitável.
- **Encerramento explícito obrigatório**: ao sair do player, ao fechar o app,
  ao perder o foco. Uma conexão pendurada bloqueia a próxima reprodução até o
  servidor expirar a sessão.
- Vale expor em Ajustes um botão de diagnóstico que mostre `active_cons` — é a
  forma de descobrir uma conexão presa.

### 6.5 EPG

`get_short_epg` funciona e devolve `start`, `end`, `start_timestamp`,
`now_playing` e `has_archive`. É o suficiente para o mini-guia ao trocar de
canal, a 1 kB por canal.

Para a grade completa existe `xmltv.php`, que numa medição devolveu 4,8 MB e
noutra veio vazio — provavelmente o mesmo problema do `Accept-Encoding`, ou
limite do servidor. A grade completa fica atrás do mini-guia na fila, e a
decisão de como carregá-la depende de mais uma medição na hora de implementar.

O fuso do servidor é `America/Sao_Paulo`, igual ao seu — sem ajuste de
horário, um problema a menos.

## 7. O que se mantém

A reescrita é da camada de navegação e interface. **Não se mexe** no que já foi
testado e funciona:

- `boot.js` e todo o mecanismo de atualização pelo GitHub, incluindo a
  reversão automática — testado, inclusive o cenário de pacote quebrado.
- `store.js`, `cloud.js` e o esquema do Supabase.
- `xtream.js`, `m3u.js` e a dedução de credenciais.
- `player.js` — o vídeo roda liso; mexer só na camada de controles.
- `check-secrets.js` e o `.gitignore` corrigido.

---

## 8. Plano de execução

Em camadas, cada uma verificável sozinha. Nenhuma camada começa antes da
anterior passar nos testes.

| # | Camada | Entrega | Como se valida |
|---|---|---|---|
| 1 | **Motor de navegação** ✅ | `nav.js` reescrito: árvore de regiões, bordas que param, memória por região, rolagem com cálculo correto, throttle por quadro | **Feito.** `node tools/test-nav.js` — 49 verificações, todas passando |
| 2 | **Purga de performance** ✅ | CSS reescrito sob as regras da seção 4; `#ambient` removido; sem sombra em card; sem `will-change` no CSS; menu de largura fixa; esqueleto por opacidade | **Feito.** `npm run test:perf` compara as duas políticas com CPU 4× mais lenta: quadros travados caíram de **25% para 3%**, pior quadro de 633ms para 83ms |
| 3 | **Virtualização** | Fileiras e grades renderizam só a janela visível + margem | Contagem de nós DOM ≤ 1200 com catálogo de 50 mil itens no mock |
| 4 | **Telas** | `views.js` reescrito em cima do novo motor, com as regiões declaradas | Testes de percurso + capturas de cada tela |
| 5 | **Dados** | Cliente da API por POST, cache granular em IndexedDB, agrupamento de qualidade por região | Tempo até catálogo visível, com e sem cache |
| 6 | **Validação na TV** | Instalar, medir na TV real, ajustar | Você navegando e dizendo se ficou fluido |

---

## 9. Como validar

O que existe hoje (`tools/smoke.js`, `tools/test-update.js`) continua valendo.
Acrescentar:

- **`tools/test-nav.js`** — percorre cada tela em todas as direções a partir de
  cada elemento e compara com a tabela 3.3. É o teste que teria pego os dois
  sintomas relatados.
- **`tools/perf.js`** — abre o app com CPU limitada, simula 40 movimentos de
  foco consecutivos, e reporta duração de quadro (p50, p95, pior caso) e
  contagem de camadas. Falha se p95 > 16ms.
- **Medição na TV**, não só no Mac. `npm run log` abre o inspetor do Chrome
  apontado para a TV; é lá que os números valem.

---

## 10. Decisões

**Todas respondidas.** Ver a tabela de decisões em `SPEC-EXPERIENCIA.md` §11:
menu sempre estreito com ícones; fundo ambiente removido; Filmes/Séries mantém
coluna de categorias + grade, agora com regiões de verdade.

---

## Fontes

**webOS / LG**
[Design Principles](https://webostv.developer.lge.com/develop/guides/design-principles) ·
[Home Screen](https://webostv.developer.lge.com/develop/guides/home-screen) ·
[Back Button](https://webostv.developer.lge.com/develop/guides/back-button) ·
[Web API & Web Engine](https://webostv.developer.lge.com/develop/specifications/web-api-and-web-engine) ·
[App Resolution](https://webostv.developer.lge.com/develop/specifications/app-resolution)

**Navegação espacial**
[CSS Spatial Navigation Level 1 (CSSWG)](https://drafts.csswg.org/css-nav-1/) ·
[Norigin Spatial Navigation](https://github.com/NoriginMedia/Norigin-Spatial-Navigation) ·
[BBC LRUD](https://github.com/bbc/lrud) ·
[js-spatial-navigation](https://github.com/luke-chang/js-spatial-navigation) ·
[react-tv-space-navigation](https://github.com/bamlab/react-tv-space-navigation)

**Performance**
[web.dev — compositor-only properties & layer count](https://web.dev/articles/stick-to-compositor-only-properties-and-manage-layer-count) ·
[web.dev — paint complexity](https://web.dev/articles/simplify-paint-complexity-and-reduce-paint-areas) ·
[Samsung — Application Performance Improvement](https://developer.samsung.com/smarttv/develop/guides/application-performance-improvement/application-performance-improvement.html) ·
[Samsung — Launch Time Optimization](https://developer.samsung.com/smarttv/develop/guides/application-performance-improvement/launch-time-optimization.html)

**Arquitetura IPTV**
[jellyfin-webos #108](https://github.com/jellyfin/jellyfin-webos/issues/108) ·
[Fórum Jellyfin — imagens lentas no webOS](https://forum.jellyfin.org/t-webos-images-load-very-slow-with-large-libraries-possible-mitigation) ·
[Kodi pvr.iptvsimple](https://github.com/kodi-pvr/pvr.iptvsimple/blob/Omega/README.md) ·
[Xtream Codes API](https://github.com/worldofiptvcom/xtream-codes-api-documentation) ·
[Moonfin Smart-TV](https://github.com/Moonfin-Client/Smart-TV)

**UX de TV**
[Android TV — Design for TV](https://developer.android.com/design/ui/tv/guides/foundations/design-for-tv) ·
[Android TV — Layouts](https://developer.android.com/design/ui/tv/guides/styles/layouts) ·
[Android TV — Focus system](https://developer.android.com/design/ui/tv/guides/styles/focus-system) ·
[Microsoft — Designing for Xbox and TV](https://learn.microsoft.com/en-us/windows/apps/design/devices/designing-for-tv)

### Lacunas declaradas

Coisas que a pesquisa **não** conseguiu confirmar, e que portanto não viraram
número nesta spec: não há orçamento oficial de DOM/camadas/memória publicado
por LG ou Samsung; a página do Magic Remote da LG não é extraível
automaticamente, então não há aqui número de alvo mínimo para o ponteiro; o
TechBlog da Netflix bloqueia acesso automatizado; não há material de engenharia
público de Plex ou Emby sobre catálogos grandes em TV; e "continuar assistindo
como primeira fileira" é convenção de mercado observada, não requisito
documentado.
