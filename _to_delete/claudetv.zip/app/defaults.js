/* Gerado por tools/build.js a partir de nebula.config.json. Nao edite. */
window.NEBULA_DEFAULTS = null;
