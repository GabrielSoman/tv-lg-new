#!/usr/bin/env node
/* =========================================================
   Testa o mecanismo de atualização — a parte mais arriscada
   do projeto, porque é ela que pode deixar a TV com um app
   quebrado se estiver errada.

   Carrega a casca de verdade (app/index.html), aponta o
   atualizador para um "GitHub" local, e verifica:
     1. a casca sobe usando a cópia local do .ipk;
     2. check() enxerga a versão publicada;
     3. install() guarda o pacote e o app reinicia com ele;
     4. um pacote quebrado é revertido sozinho no boot seguinte.

   Precisa do dev-server rodando:  npm run dev
   ========================================================= */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE = process.env.APP_URL || 'http://localhost:8088';
const SHELL = BASE + '/app/index.html';
const FEED = BASE + '/build';
const MOCK = process.env.MOCK_URL || 'http://localhost:9099';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fails = [];
function check(label, ok, detail) {
  console.log((ok ? '  ok   ' : '  FALHA') + '  ' + label + (detail ? '  — ' + detail : ''));
  if (!ok) fails.push(label);
}

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  page.on('pageerror', (e) => console.log('    [pageerror]', e.message));

  /* Limpa só na primeira carga: os recarregamentos seguintes precisam
     encontrar o pacote que acabou de ser instalado. */
  await page.addInitScript((cfg) => {
    if (sessionStorage.getItem('nebula.test.pronto')) return;
    try { localStorage.clear(); } catch (e) {}
    localStorage.setItem('nebula.settings', JSON.stringify({
      source: {
        url: cfg.mock + '/get.php?username=teste&password=123',
        mode: 'xtream', origin: cfg.mock, username: 'teste', password: '123'
      },
      update: { customUrl: cfg.feed }
    }));
    sessionStorage.setItem('nebula.test.pronto', '1');
  }, { feed: FEED, mock: MOCK });

  console.log('\n1) primeira abertura — deve usar a cópia local do .ipk');
  await page.goto(SHELL, { waitUntil: 'domcontentloaded' });
  await sleep(7500);   /* a aprovação da versão só vem 6 s depois de subir */
  let loaded = await page.evaluate(() => window.Updater.loaded);
  check('subiu pela cópia local', loaded.source === 'local', 'versão ' + loaded.version);
  check('o app confirmou a inicialização', await page.evaluate(() => window.Updater.confirmed));
  check('a tela de carregamento sumiu',
        await page.evaluate(() => !document.getElementById('shell-boot')));
  const localVersion = loaded.version;

  console.log('\n2) procurar atualização');
  const info = await page.evaluate(() => window.Updater.check());
  check('achou o manifest', !!info.version, 'publicada: ' + info.version);
  check('detectou que é diferente da local', info.isNew === (info.version !== localVersion));

  console.log('\n3) instalar e reiniciar');
  await page.evaluate((i) => window.Updater.install(i), info);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await sleep(7500);
  loaded = await page.evaluate(() => window.Updater.loaded);
  check('subiu pelo pacote baixado', loaded.source === 'github', 'versão ' + loaded.version);
  check('o app confirmou de novo', await page.evaluate(() => window.Updater.confirmed));
  check('a marca de verificação foi apagada',
        await page.evaluate(() => localStorage.getItem('nebula.bundle.verify') === null));
  check('o catálogo continua funcionando',
        (await page.evaluate(() => document.querySelectorAll('.card').length)) > 0);

  console.log('\n4) publicar um pacote quebrado — a TV deve se salvar sozinha');
  const good = fs.readFileSync(path.join(ROOT, 'build', 'app.js'), 'utf8');
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'manifest.json'), 'utf8'));
  try {
    fs.writeFileSync(path.join(ROOT, 'build', 'app.js'),
      ';(function(){ throw new Error("versao proposital quebrada"); })();\n' + good);
    const bad = Object.assign({}, manifest, { version: 'QUEBRADA' });
    fs.writeFileSync(path.join(ROOT, 'build', 'manifest.json'), JSON.stringify(bad, null, 2));

    const badInfo = await page.evaluate(() => window.Updater.check());
    await page.evaluate((i) => window.Updater.install(i), badInfo);

    await page.reload({ waitUntil: 'domcontentloaded' });
    await sleep(1400);
    const brokenBooted = await page.evaluate(() => !!window.Updater.confirmed);
    check('a versão quebrada realmente não subiu', !brokenBooted);

    /* A própria casca se recarrega ao ver o erro; damos tempo para isso. */
    await sleep(9000);
    loaded = await page.evaluate(() => window.Updater.loaded);
    check('reverteu sozinho no boot seguinte', !!loaded.rolledBackFrom,
          'revertida: ' + loaded.rolledBackFrom);
    check('o app voltou a funcionar', await page.evaluate(() => window.Updater.confirmed),
          'rodando ' + loaded.version);
    check('o catálogo voltou',
          (await page.evaluate(() => document.querySelectorAll('.card').length)) > 0);
  } finally {
    fs.writeFileSync(path.join(ROOT, 'build', 'app.js'), good);
    fs.writeFileSync(path.join(ROOT, 'build', 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  }

  await browser.close();

  console.log('\n=============================');
  if (fails.length) {
    console.log('FALHOU em ' + fails.length + ' verificação(ões):');
    fails.forEach((f) => console.log('  • ' + f));
    process.exit(1);
  }
  console.log('Atualização pelo GitHub: tudo funcionando, inclusive a reversão.');
})().catch((e) => { console.error('o teste quebrou:', e); process.exit(1); });
