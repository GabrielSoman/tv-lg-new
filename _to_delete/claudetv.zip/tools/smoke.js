#!/usr/bin/env node
/* =========================================================
   Teste de fumaça: abre o app num navegador sem janela,
   percorre as telas com as setas e reclama de qualquer erro
   de JavaScript. Roda contra o servidor de desenvolvimento
   e o IPTV de mentira.

     node tools/mock-iptv.js &
     node tools/dev-server.js &
     node tools/smoke.js
   ========================================================= */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

const APP = process.env.APP_URL || 'http://localhost:8088';
const MOCK = process.env.MOCK_URL || 'http://localhost:9099';
const SHOTS = path.resolve(__dirname, '..', 'shots');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 },
                                       deviceScaleFactor: 1 });

  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error') {
      const t = m.text();
      /* Falhas de rede de vídeo são esperadas: o mock não serve vídeo. */
      if (/net::ERR|Failed to load resource|media|video/i.test(t)) return;
      errors.push('console: ' + t);
    }
  });

  /* Começa do zero: o app deve mostrar a tela de configuração. */
  await page.addInitScript(() => {
    try { localStorage.clear(); } catch (e) {}
  });

  const key = async (k, times = 1, wait = 130) => {
    for (let i = 0; i < times; i++) { await page.keyboard.press(k); await sleep(wait); }
  };
  const shot = async (name) => {
    await page.screenshot({ path: path.join(SHOTS, name + '.png') });
    console.log('  → shots/' + name + '.png');
  };

  console.log('abrindo o app…');
  await page.goto(APP, { waitUntil: 'domcontentloaded' });
  await sleep(600);

  /* Tela de configuração: preenche e conecta. */
  console.log('conectando a lista…');
  await page.fill('.screen-setup input', MOCK + '/get.php?username=teste&password=123');
  await page.click('.screen-setup .btn.primary');
  await sleep(2500);
  await shot('01-inicio');

  const routeOf = () => page.evaluate(() => window.App.current());
  console.log('  rota:', await routeOf());

  /* Navega pelas fileiras da tela inicial. */
  console.log('navegando na tela inicial…');
  await key('ArrowDown', 3, 260);
  await key('ArrowRight', 6, 170);
  await sleep(700);
  await shot('02-inicio-fileiras');

  /* Vai para Ao Vivo pelo menu. */
  console.log('abrindo Ao Vivo…');
  await page.evaluate(() => window.App.go('live'));
  await sleep(1800);
  await key('ArrowDown', 2, 300);
  await sleep(900);
  await shot('03-ao-vivo');

  console.log('abrindo Filmes…');
  await page.evaluate(() => window.App.go('movies'));
  await sleep(1800);
  await key('ArrowRight', 1, 250);
  await key('ArrowRight', 4, 170);
  await sleep(600);
  await shot('04-filmes');

  /* Entra no detalhe de um filme. */
  console.log('abrindo o detalhe de um filme…');
  await key('Enter', 1, 1600);
  console.log('  rota:', await routeOf());
  await shot('05-detalhe-filme');

  /* Séries + detalhe com temporadas. */
  console.log('abrindo Séries…');
  await page.evaluate(() => window.App.go('series'));
  await sleep(1800);
  await key('ArrowRight', 2, 250);
  await key('Enter', 1, 2000);
  console.log('  rota:', await routeOf());
  await shot('06-detalhe-serie');
  await key('ArrowDown', 3, 300);
  await shot('07-episodios');

  /* Busca. */
  console.log('testando a busca…');
  await page.evaluate(() => window.App.go('search'));
  await sleep(2500);
  await page.fill('.screen-search input', 'aurora');
  await sleep(1200);
  await shot('08-busca');
  const hits = await page.evaluate(() => document.querySelectorAll('.screen-search .grid .card').length);
  console.log('  resultados:', hits);

  /* Ajustes. */
  console.log('abrindo Ajustes…');
  await page.evaluate(() => window.App.go('settings'));
  await sleep(900);
  await shot('09-ajustes');

  /* Player: abre um episódio e confere que grava o progresso. */
  console.log('testando o player e a gravação de progresso…');
  await page.evaluate(() => {
    window.Player.open({
      id: 'movie:9999', kind: 'movie', title: 'Teste de Player',
      subtitle: 'verificação automática', poster: '', url: 'about:blank', duration: 0
    });
  });
  await sleep(800);
  await page.evaluate(() => {
    const v = document.getElementById('video');
    Object.defineProperty(v, 'currentTime', { get: () => 754, configurable: true });
    Object.defineProperty(v, 'duration',    { get: () => 5400, configurable: true });
  });
  await sleep(300);
  await shot('10-player');
  await page.evaluate(() => window.Player.close());
  await sleep(400);

  const saved = await page.evaluate(() => {
    const p = JSON.parse(localStorage.getItem('nebula.progress') || '{}');
    return p['movie:9999'] || null;
  });
  console.log('  progresso gravado:', saved ? Math.round(saved.position) + 's de ' +
              Math.round(saved.duration) + 's' : 'NADA');
  if (!saved || Math.round(saved.position) !== 754) errors.push('progresso não foi gravado corretamente');

  /* O item deve reaparecer em "Continuar assistindo". */
  await page.evaluate(() => window.App.go('home'));
  await sleep(2200);
  const cont = await page.evaluate(() =>
    Array.prototype.slice.call(document.querySelectorAll('.section-title span'))
      .map((n) => n.textContent));
  console.log('  fileiras na home:', cont.join(' | '));
  if (!cont.some((t) => /Continuar/.test(t))) errors.push('a fileira "Continuar assistindo" não apareceu');
  await shot('11-continuar-assistindo');

  /* Voltar deve sair do detalhe. */
  await page.evaluate(() => window.App.go('movies'));
  await sleep(1500);
  await key('ArrowRight', 1, 250);
  await key('Enter', 1, 1500);
  const before = await routeOf();
  await key('Backspace', 1, 1200);
  const after = await routeOf();
  console.log('  voltar:', before, '→', after);
  if (before === after) errors.push('a tecla Voltar não mudou de tela');

  await browser.close();

  console.log('\n=============================');
  if (errors.length) {
    console.log('ERROS ENCONTRADOS (' + errors.length + '):');
    errors.forEach((e) => console.log('  • ' + e));
    process.exit(1);
  }
  console.log('Nenhum erro de JavaScript. Tudo passou.');
})().catch((e) => { console.error('o teste quebrou:', e); process.exit(1); });
