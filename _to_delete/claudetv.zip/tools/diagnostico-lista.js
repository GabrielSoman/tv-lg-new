#!/usr/bin/env node
/* =========================================================
   RAIO-X DA LISTA — versão 3
   =========================================================
   A API funciona. O que enganava era o `Accept-Encoding`:
   pedindo gzip, o painel devolvia 200 com corpo vazio. Sem
   pedir compressão (ou por POST), ele responde JSON normal.

   Este script agora fala com a API do jeito certo e levanta
   tudo que a arquitetura de dados precisa saber:

     · tamanho de cada resposta — é isso que decide o que dá
       para baixar na TV e o que precisa ser paginado
     · estrutura de séries: temporadas, episódios, duração
     · campos de filme: backdrop, tmdb, sinopse, elenco
     · canais duplicados, separando QUALIDADE de REGIÃO
     · EPG: tamanho e cobertura
     · CORS: se a TV vai precisar de proxy

       node tools/diagnostico-lista.js

   O relatório não contém usuário, senha nem endereço.
   ========================================================= */

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const zlib = require('zlib');
const { URL } = require('url');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'relatorio-lista.md');
const L = [];
const diz = (s = '') => { L.push(s); console.log(s); };
const mb = (n) => (n / 1048576).toFixed(2) + ' MB';
const kb = (n) => (n / 1024).toFixed(0) + ' kB';

const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'nebula.config.json'), 'utf8'));
const SRC = new URL((cfg.source || {}).url);
const USER = SRC.searchParams.get('username') || SRC.searchParams.get('user');
const PASS = SRC.searchParams.get('password') || SRC.searchParams.get('pass');
const BASE = `${SRC.protocol}//${SRC.host}`;

function mascarar(t) {
  if (!t) return t;
  let s = String(t);
  [USER, PASS, SRC.hostname, BASE].forEach((v) => { if (v) s = s.split(v).join('«oculto»'); });
  return s;
}

/* ---------- rede ---------- */
function pedir(url, { metodo = 'GET', corpo = null, gzip = false, maxTexto = 0, ms = 60000 } = {}) {
  return new Promise((resolve) => {
    let u; try { u = new URL(url); } catch { return resolve({ erro: 'url inválida' }); }
    const mod = u.protocol === 'https:' ? https : http;
    const h = { 'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept': '*/*' };
    if (gzip) h['Accept-Encoding'] = 'gzip, deflate';
    if (corpo) {
      h['Content-Type'] = 'application/x-www-form-urlencoded';
      h['Content-Length'] = Buffer.byteLength(corpo);
    }
    const req = mod.request(u, { method: metodo, headers: h, rejectUnauthorized: false }, (res) => {
      const enc = (res.headers['content-encoding'] || '').toLowerCase();
      let f = res;
      if (enc === 'gzip') f = res.pipe(zlib.createGunzip());
      else if (enc === 'deflate') f = res.pipe(zlib.createInflate());
      let txt = '', bytes = 0, pronto = false;
      const fim = () => {
        if (pronto) return; pronto = true;
        resolve({ status: res.statusCode, tipo: res.headers['content-type'] || '',
                  cors: res.headers['access-control-allow-origin'] || null,
                  enc, bytes, corpo: txt });
      };
      f.on('data', (c) => {
        bytes += c.length;
        if (!maxTexto || txt.length < maxTexto) txt += c.toString('utf8');
        if (maxTexto && txt.length >= maxTexto) { try { req.destroy(); } catch (e) {} fim(); }
      });
      f.on('end', fim); f.on('error', fim);
      res.on('aborted', fim); res.on('error', fim);
    });
    req.on('error', (e) => resolve({ erro: e.message }));
    req.setTimeout(ms, () => { req.destroy(); resolve({ erro: 'tempo esgotado' }); });
    if (corpo) req.write(corpo);
    req.end();
  });
}

let CORS_API;
const medidas = [];

async function chamar(action, extra = {}) {
  let corpo = `username=${encodeURIComponent(USER)}&password=${encodeURIComponent(PASS)}`;
  if (action) corpo += `&action=${action}`;
  Object.keys(extra).forEach((k) => { corpo += `&${k}=${encodeURIComponent(extra[k])}`; });
  const r = await pedir(`${BASE}/player_api.php`, { metodo: 'POST', corpo });
  const rotulo = action || '(conta)';
  if (r.erro) { medidas.push({ a: rotulo, erro: r.erro }); return null; }
  if (CORS_API === undefined) CORS_API = r.cors;
  medidas.push({ a: rotulo, bytes: r.bytes });
  try { return JSON.parse(r.corpo); } catch { return null; }
}

/* ---------- normalização ---------- */
const QUALIDADES = ['4K', 'UHD', 'ULTRA HD', '2160P', 'FHD', 'FULL HD', '1080P',
                    'HD', '720P', 'SD', '480P', 'H265', 'HEVC', 'H264', '60FPS'];
/* Prefixos de FEED/REGIÃO. Nunca agrupar entre eles: LAT|HBO fala espanhol. */
const REGIOES = ['LAT', 'USL', 'USA', 'US', 'PT', 'BR', 'ES', 'AR', 'MX', 'UK', 'IT', 'FR', 'DE'];

const semAcento = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');

/* HD escrito em unicode sobrescrito (ᴴᴰ) aparece na lista e enganava o detector. */
function normalizaUnicode(s) {
  return String(s || '')
    .replace(/ᶠ?ᴴᴰ/g, ' HD ')
    .replace(/ᴴᴰ/g, ' HD ')
    .replace(/[ᴬ-ᵪʰ-˿]/g, '');
}

function decompor(nome) {
  let s = normalizaUnicode(semAcento(nome)).toUpperCase();
  let regiao = '';
  const mr = s.match(/^\s*([A-Z]{2,4})\s*[|\-:]\s*/);
  if (mr && REGIOES.indexOf(mr[1]) >= 0) { regiao = mr[1]; s = s.slice(mr[0].length); }

  const marcas = [];
  QUALIDADES.forEach((q) => {
    const re = new RegExp('(^|[\\s\\[\\(\\-|])' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') +
                          '($|[\\s\\]\\)\\-|])', 'g');
    if (re.test(s)) { marcas.push(q); s = s.replace(re, ' '); }
  });
  /* preserva + e números: HBO+ ≠ HBO, ESPN 2 ≠ ESPN */
  s = s.replace(/[\[\]()|·!]/g, ' ').replace(/[^A-Z0-9+\s]/g, ' ')
       .replace(/\s{2,}/g, ' ').trim();
  return { base: s, marcas, regiao };
}

const ADULTO = /(^|\W)(adulto?s?|xxx|\+?18\+?|adult|porn|erotic|eroticos?|hentai)(\W|$)/i;

/* ========================================================= */
(async () => {
  diz('# Raio-x da lista — pela API');
  diz('');
  diz('> Sem credenciais, sem endereços.');
  diz('');

  const conta = await chamar('');
  if (!conta || !conta.user_info) { diz('**A API não respondeu.**'); return salvar(); }
  const ui = conta.user_info, si = conta.server_info || {};

  diz('## Conta');
  diz('');
  diz(`- status \`${ui.status}\` · **conexões simultâneas: \`${ui.max_connections}\`** (ativas \`${ui.active_cons}\`)`);
  diz(`- expira em \`${ui.exp_date ? new Date(Number(ui.exp_date) * 1000).toISOString().slice(0, 10) : '—'}\``);
  diz(`- fuso do servidor: \`${si.timezone || '—'}\``);
  diz(`- formatos permitidos: \`${(ui.allowed_output_formats || []).join('`, `')}\``);
  diz('');
  diz(`- \`Access-Control-Allow-Origin\` na API: **${CORS_API ? '`' + CORS_API + '`' : 'AUSENTE'}**`);
  diz('');

  /* categorias */
  const [cl, cv, cs] = await Promise.all([
    chamar('get_live_categories'), chamar('get_vod_categories'), chamar('get_series_categories')
  ]);
  const arr = (a) => (Array.isArray(a) ? a : []);
  const nomes = (a) => arr(a).map((c) => String(c.category_name || '').trim());
  const adultas = [...nomes(cl), ...nomes(cv), ...nomes(cs)].filter((n) => ADULTO.test(semAcento(n)));

  diz('## Categorias');
  diz('');
  diz(`- ao vivo **${arr(cl).length}** · filmes **${arr(cv).length}** · séries **${arr(cs).length}**`);
  diz('');
  diz('Detectadas como adultas:');
  diz('');
  diz(adultas.length ? adultas.map((n) => `- \`${n}\``).join('\n') : '- (nenhuma)');
  diz('');

  /* canais */
  const canais = await chamar('get_live_streams');
  const lista = Array.isArray(canais) ? canais : [];
  diz('## Canais ao vivo');
  diz('');
  diz(`Total: **${lista.length.toLocaleString('pt-BR')}**`);
  if (lista[0]) diz('Campos: `' + Object.keys(lista[0]).join('`, `') + '`');
  diz('');

  const freq = {}, regioes = {}, grupos = new Map();
  lista.forEach((c) => {
    const { base, marcas, regiao } = decompor(c.name);
    marcas.forEach((m) => { freq[m] = (freq[m] || 0) + 1; });
    if (regiao) regioes[regiao] = (regioes[regiao] || 0) + 1;
    if (!base) return;
    const chave = (regiao ? regiao + ' :: ' : '') + base;
    if (!grupos.has(chave)) grupos.set(chave, []);
    grupos.get(chave).push({ nome: c.name, marcas });
  });

  diz('### Marcadores de qualidade');
  diz('');
  diz(Object.entries(freq).sort((a, b) => b[1] - a[1]).map(([m, n]) => `- \`${m}\` — ${n}`).join('\n') || '- (nenhum)');
  diz('');
  diz('### Prefixos de região');
  diz('');
  diz(Object.entries(regioes).sort((a, b) => b[1] - a[1]).map(([r, n]) => `- \`${r}\` — ${n}`).join('\n') || '- (nenhum)');
  diz('');
  diz('> São **feeds diferentes**, não qualidades. O agrupamento abaixo os mantém');
  diz('> separados, para a troca automática nunca mudar o idioma do canal.');
  diz('');

  const dup = [...grupos.entries()].filter(([, v]) => v.length > 1).sort((a, b) => b[1].length - a[1].length);
  diz('### Variantes de qualidade (já separadas por região)');
  diz('');
  diz(`**${dup.length}** de **${grupos.size}** canais distintos têm variantes. ` +
      `A lista cairia de **${lista.length.toLocaleString('pt-BR')}** para **${grupos.size.toLocaleString('pt-BR')}**.`);
  diz('');
  dup.slice(0, 15).forEach(([chave, v]) => {
    diz(`- **${chave}** — ${v.length}`);
    v.forEach((x) => diz(`    - \`${x.nome}\` → ${x.marcas.join(', ') || '(sem marca)'}`));
  });
  diz('');

  /* filmes */
  diz('## Filmes');
  diz('');
  const catV = arr(cv)[0];
  const filmes = catV ? await chamar('get_vod_streams', { category_id: catV.category_id }) : [];
  const lf = Array.isArray(filmes) ? filmes : [];
  diz(`Categoria \`${((catV && catV.category_name) || '').trim()}\`: **${lf.length}** filmes.`);
  if (lf[0]) {
    diz('Campos: `' + Object.keys(lf[0]).join('`, `') + '`');
    const ext = {};
    lf.forEach((f) => { const e = (f.container_extension || '?').toLowerCase(); ext[e] = (ext[e] || 0) + 1; });
    diz('Formatos: ' + Object.entries(ext).map(([e, n]) => `\`.${e}\` ${n}`).join(' · '));
    diz('');
    const inf = await chamar('get_vod_info', { vod_id: lf[0].stream_id });
    const i = (inf && inf.info) || {};
    diz('Campos de `get_vod_info` → `info`:');
    diz('');
    ['tmdb_id', 'backdrop_path', 'youtube_trailer', 'genre', 'plot', 'cast', 'director',
     'rating', 'releasedate', 'duration_secs', 'movie_image', 'o_name'].forEach((k) => {
      const v = i[k];
      const tem = v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && !v.length);
      diz(`- \`${k}\`: **${tem ? 'presente' : 'ausente'}**` +
          (tem && typeof v === 'string' && v.length < 70 ? ` — \`${mascarar(v)}\`` : '') +
          (tem && Array.isArray(v) ? ` — ${v.length} item(ns)` : ''));
    });
    diz('');
    diz('Todas as chaves: `' + Object.keys(i).join('`, `') + '`');
    diz('');
  }

  /* séries */
  diz('## Séries — a parte que hoje não existe no app');
  diz('');
  const catS = arr(cs)[0];
  const series = catS ? await chamar('get_series', { category_id: catS.category_id }) : [];
  const ls = Array.isArray(series) ? series : [];
  diz(`Categoria \`${((catS && catS.category_name) || '').trim()}\`: **${ls.length}** séries.`);
  if (ls[0]) {
    diz('Campos de `get_series`: `' + Object.keys(ls[0]).join('`, `') + '`');
    diz('');
    const si2 = await chamar('get_series_info', { series_id: ls[0].series_id });
    const eps = (si2 && si2.episodes) || {};
    const temps = Object.keys(eps);
    let total = 0, comDur = 0; const ext = {};
    temps.forEach((t) => (eps[t] || []).forEach((e) => {
      total++;
      const x = (e.container_extension || '?').toLowerCase();
      ext[x] = (ext[x] || 0) + 1;
      const ei = e.info || {};
      if (ei.duration_secs || ei.duration) comDur++;
    }));
    diz(`Série de amostra: **${temps.length}** temporada(s), **${total}** episódios.`);
    diz(`- formatos: ${Object.entries(ext).map(([e, n]) => `\`.${e}\` ${n}`).join(' · ') || '—'}`);
    diz(`- com duração informada: **${comDur}/${total}**` +
        (total && comDur < total ? ' — sem isso não dá para saber quando o episódio acaba' : ''));
    const e0 = (eps[temps[0]] || [])[0];
    if (e0) {
      diz('- campos do episódio: `' + Object.keys(e0).join('`, `') + '`');
      diz('- campos de `episode.info`: `' + Object.keys(e0.info || {}).join('`, `') + '`');
    }
    diz('');
  }

  /* EPG */
  diz('## EPG');
  diz('');
  if (lista[0]) {
    const ce = await chamar('get_short_epg', { stream_id: lista[0].stream_id, limit: 3 });
    const it = (ce && ce.epg_listings) || [];
    diz(`- \`get_short_epg\`: **${it.length}** programa(s) num canal de amostra.`);
    if (it[0]) {
      const dec = (s) => { try { return Buffer.from(s || '', 'base64').toString('utf8'); } catch { return '(?)'; } };
      diz(`    - exemplo: \`${dec(it[0].title)}\` · início \`${it[0].start}\``);
      diz('    - campos: `' + Object.keys(it[0]).join('`, `') + '`');
    }
  }
  const x = await pedir(`${BASE}/xmltv.php?username=${encodeURIComponent(USER)}` +
                        `&password=${encodeURIComponent(PASS)}&gzip=1`,
                        { gzip: true, maxTexto: 300000, ms: 90000 });
  if (!x.erro) {
    diz(`- \`xmltv.php?gzip=1\` → HTTP ${x.status}, \`${x.tipo}\`, **${mb(x.bytes)}**` +
        (x.enc ? ` (comprimido: \`${x.enc}\`)` : ' (sem compressão no transporte)'));
    diz(`    - no trecho lido: ${(x.corpo.match(/<channel\s/g) || []).length} canais, ` +
        `${(x.corpo.match(/<programme\s/g) || []).length} programas`);
    const m = x.corpo.match(/<programme[^>]*start="([^"]+)"/);
    if (m) diz(`    - formato de horário: \`${m[1]}\``);
  } else diz(`- \`xmltv.php?gzip=1\` falhou: ${x.erro}`);
  diz('');

  /* tamanhos */
  diz('## Tamanho de cada chamada — é isto que define a arquitetura');
  diz('');
  diz('| chamada | resposta |');
  diz('|---|---|');
  medidas.forEach((m) => diz(`| \`${m.a}\` | ${m.erro ? '**erro:** ' + m.erro : (m.bytes > 1e6 ? mb(m.bytes) : kb(m.bytes))} |`));
  diz('');
  diz('Comparação: a lista M3U completa tem **81,5 MB**.');
  diz('');

  salvar();
})().catch((e) => { diz('quebrou: ' + e.message); salvar(); });

function salvar() {
  fs.writeFileSync(OUT, L.join('\n') + '\n');
  console.log('\n---\nSalvo em relatorio-lista.md');
}
