#!/usr/bin/env node
/* =========================================================
   TESTE DO MOTOR DE NAVEGAÇÃO
   =========================================================
   Percorre cada tela em todas as direções e confere, borda a
   borda, o comportamento definido na tabela 3.3 do SPEC.md.

   É o teste que teria pego os dois defeitos relatados:
     · o foco vazando da coluna de categorias para a grade
     · o foco continuando a descer sem a rolagem acompanhar

   Precisa do servidor de desenvolvimento:
       npm run dev
   e então:
       node tools/test-nav.js
   ========================================================= */
const { chromium } = require('playwright');

const URL_FIXTURE = (process.env.APP_URL || 'http://localhost:8088') + '/tools/nav-fixture.html';

let page;
const falhas = [];
let contador = 0;

async function ok(rotulo, real, esperado) {
  contador++;
  const bate = JSON.stringify(real) === JSON.stringify(esperado);
  console.log(`  ${bate ? 'ok   ' : 'FALHA'}  ${rotulo}` +
              (bate ? '' : `\n           esperado: ${JSON.stringify(esperado)}` +
                           `\n           veio:     ${JSON.stringify(real)}`));
  if (!bate) falhas.push(rotulo);
}

const tela   = (n) => page.evaluate((x) => window.mostrar(x), n);
const focar  = (id) => page.evaluate((x) => window.focar(x), id);
const mover  = (d) => page.evaluate((x) => window.mover(x), d);
const foco   = () => page.evaluate(() => window.foco());
const regiao = () => page.evaluate(() => window.regiao());
const dentro = () => page.evaluate(() => window.dentroDaJanela());

/* Move e devolve {moveu, foco, regiao} */
async function passo(dir) {
  const moveu = await mover(dir);
  return { moveu, foco: await foco(), regiao: await regiao() };
}

(async () => {
  const browser = await chromium.launch();
  page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  page.on('pageerror', (e) => falhas.push('erro de JS: ' + e.message));
  await page.goto(URL_FIXTURE, { waitUntil: 'load' });

  /* =======================================================
     1. Coluna de categorias — os dois bugs relatados
     ======================================================= */
  console.log('\n1) Coluna de categorias');
  await tela('browse');

  await focar('c1');
  await ok('no topo, ↑ não sai da coluna', await passo('up'),
           { moveu: false, foco: 'c1', regiao: 'cats' });

  await ok('↓ desce uma categoria', await passo('down'),
           { moveu: true, foco: 'c2', regiao: 'cats' });

  await ok('← vai para o menu', await passo('left'),
           { moveu: true, foco: 'm1', regiao: 'rail' });

  await focar('c2');
  await ok('→ entra na grade', await passo('right'),
           { moveu: true, foco: 'g1', regiao: 'grid' });

  /* O bug principal: descer até o fim NÃO pode cair na grade. */
  await focar('c1');
  for (let i = 0; i < 80; i++) await mover('down');
  await ok('descendo até o fim, continua nas categorias', await regiao(), 'cats');
  await ok('para na última categoria', await foco(), 'c60');
  await ok('↓ na última não move', (await passo('down')).moveu, false);

  /* O outro bug: a rolagem tem de acompanhar o foco. */
  await ok('a última categoria está visível na janela', await dentro(), true);

  /* e no caminho todo, não só no fim */
  await focar('c1');
  let todosVisiveis = true;
  for (let i = 0; i < 59; i++) {
    await mover('down');
    if (!(await dentro())) { todosVisiveis = false; break; }
  }
  await ok('todas as 60 categorias ficam visíveis ao descer', todosVisiveis, true);

  /* subir de volta também */
  for (let i = 0; i < 59; i++) await mover('up');
  await ok('voltando ao topo, chega na primeira', await foco(), 'c1');
  await ok('e ela está visível', await dentro(), true);

  /* =======================================================
     2. Grade
     ======================================================= */
  console.log('\n2) Grade');
  await focar('g1');
  await ok('na primeira coluna, ← vai para as categorias', await passo('left'),
           { moveu: true, foco: 'c1', regiao: 'cats' });

  await focar('g1');
  await ok('na primeira linha, ↑ não sai', (await passo('up')).moveu, false);

  await focar('g2');
  await ok('→ anda na mesma linha', await passo('right'),
           { moveu: true, foco: 'g3', regiao: 'grid' });

  /* desce e sobe: tem de voltar para a MESMA coluna */
  await focar('g3');
  const col = await foco();
  await mover('down');
  const abaixo = await foco();
  await mover('up');
  await ok('descer e subir volta para a mesma coluna', await foco(), col);
  await ok('descer muda de item', abaixo !== col, true);

  /* fim da linha: → para, não pula de linha */
  await focar('g1');
  let ultimoDaLinha = 'g1', andou = 0;
  while (await mover('right')) { ultimoDaLinha = await foco(); if (++andou > 30) break; }
  await ok('no fim da linha, → para', (await passo('right')).moveu, false);
  await ok('e continua na grade', await regiao(), 'grid');

  /* última linha: ↓ para */
  for (let i = 0; i < 40; i++) await mover('down');
  await ok('na última linha, ↓ para', (await passo('down')).moveu, false);
  await ok('e o item está visível', await dentro(), true);

  /* =======================================================
     3. Menu lateral
     ======================================================= */
  console.log('\n3) Menu lateral');
  await focar('m1');
  await ok('no primeiro item, ↑ para', (await passo('up')).moveu, false);
  await focar('m6');
  await ok('no último item, ↓ para', (await passo('down')).moveu, false);
  await focar('m3');
  await ok('← não sai do menu', (await passo('left')).moveu, false);

  /* Memória de região: sai da grade, passa pelo menu, e ao voltar
     tem de cair exatamente onde estava. g1 está na primeira coluna,
     então um único ← já sai da grade. */
  await focar('g1');
  await mover('left');                                  // cats
  await ok('da primeira coluna, ← chega nas categorias', await regiao(), 'cats');
  await mover('left');                                  // rail
  await ok('e outro ← chega no menu', await regiao(), 'rail');
  await mover('right');
  await ok('→ volta para as categorias lembradas', await regiao(), 'cats');
  await mover('right');
  await ok('→ volta para a grade no item lembrado', await foco(), 'g1');

  /* A memória do menu também: entra pelo m4, sai, volta. */
  await focar('m4');
  await mover('right');
  await ok('entrou na região principal', await regiao(), 'cats');
  await mover('left');
  await ok('← volta para o item do menu de onde saiu', await foco(), 'm4');

  /* =======================================================
     4. Tela inicial: destaque + fileiras
     ======================================================= */
  console.log('\n4) Tela inicial');
  await tela('home');
  /* fixa a memória do menu no primeiro item, para a asserção ser exata */
  await focar('m1');
  await focar('h1');
  await ok('no destaque, ← vai para o menu, no item lembrado', await passo('left'),
           { moveu: true, foco: 'm1', regiao: 'rail' });

  await focar('h1');
  await ok('→ anda entre os botões do destaque', await passo('right'),
           { moveu: true, foco: 'h2', regiao: 'hero' });
  await ok('no último botão, → para', (await passo('right')).moveu, false);
  await ok('↑ no destaque para', (await passo('up')).moveu, false);

  await focar('h1');
  await ok('↓ desce para as fileiras', (await passo('down')).regiao, 'rows');

  await focar('m1');
  await focar('f1c1');
  await ok('no primeiro card, ← vai para o menu', await passo('left'),
           { moveu: true, foco: 'm1', regiao: 'rail' });

  await focar('f1c1');
  await ok('→ anda na fileira', await passo('right'),
           { moveu: true, foco: 'f1c2', regiao: 'rows' });
  await ok('↓ troca de fileira mantendo a posição', await passo('down'),
           { moveu: true, foco: 'f2c2', regiao: 'rows' });
  await ok('↑ volta para a fileira de cima', await passo('up'),
           { moveu: true, foco: 'f1c2', regiao: 'rows' });

  await focar('f1c1');
  await ok('↑ na primeira fileira vai para o destaque', (await passo('up')).regiao, 'hero');

  await focar('f6c1');
  await ok('na última fileira, ↓ para', (await passo('down')).moveu, false);

  /* rolagem horizontal da fileira */
  await focar('f1c1');
  let visiveisNaFileira = true;
  for (let i = 0; i < 19; i++) {
    await mover('right');
    if (!(await dentro())) { visiveisNaFileira = false; break; }
  }
  await ok('todos os 20 cards da fileira ficam visíveis', visiveisNaFileira, true);
  await ok('no último card, → para', (await passo('right')).moveu, false);

  /* rolagem vertical entre fileiras */
  await focar('f1c1');
  let visiveisEntreFileiras = true;
  for (let i = 0; i < 5; i++) {
    await mover('down');
    if (!(await dentro())) { visiveisEntreFileiras = false; break; }
  }
  await ok('todas as fileiras ficam visíveis ao descer', visiveisEntreFileiras, true);

  /* =======================================================
     5. Busca — o campo de texto
     ======================================================= */
  console.log('\n5) Busca');
  await tela('busca');
  await focar('q');
  await ok('↓ do campo vai para os resultados', (await passo('down')).regiao, 'resultados');
  await focar('r1');
  await ok('↑ dos resultados volta para o campo', (await passo('up')).regiao, 'campo');

  /* as setas horizontais pertencem ao campo, não à navegação */
  await focar('q');
  await page.keyboard.type('teste');
  await page.keyboard.press('ArrowLeft');
  await page.waitForTimeout(60);
  await ok('← com o campo em foco não navega', await foco(), 'q');
  await ok('e o texto continua lá',
           await page.evaluate(() => document.getElementById('q').value), 'teste');

  await page.keyboard.press('Backspace');
  await page.waitForTimeout(60);
  await ok('Backspace apaga em vez de voltar de tela',
           await page.evaluate(() => document.getElementById('q').value), 'tese');

  /* =======================================================
     6. Nenhum caminho leva a lugar nenhum
     ======================================================= */
  console.log('\n6) Varredura: nada pode escapar da própria região');
  await tela('browse');
  const regioesValidas = ['rail', 'cats', 'grid'];
  let escapou = null;
  const ids = await page.evaluate(() =>
    Array.from(document.querySelectorAll('#tela-browse [data-focusable], #rail [data-focusable]'))
      .map((e) => e.id).slice(0, 40));
  for (const id of ids) {
    for (const d of ['left', 'right', 'up', 'down']) {
      await focar(id);
      await mover(d);
      const rg = await regiao();
      if (rg && regioesValidas.indexOf(rg) < 0) { escapou = `${id} + ${d} → ${rg}`; break; }
      if (!(await dentro())) { escapou = `${id} + ${d} saiu da janela`; break; }
    }
    if (escapou) break;
  }
  await ok('160 movimentos, nenhum foco perdido ou fora da janela', escapou, null);

  await browser.close();

  console.log('\n=============================');
  console.log(`${contador - falhas.length}/${contador} verificações passaram.`);
  if (falhas.length) {
    console.log('\nFALHOU em:');
    falhas.forEach((f) => console.log('  • ' + f));
    process.exit(1);
  }
  console.log('Motor de navegação: tudo conforme a tabela 3.3 do SPEC.md.');
})().catch((e) => { console.error('o teste quebrou:', e); process.exit(1); });
