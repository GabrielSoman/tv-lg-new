#!/usr/bin/env node
/* =========================================================
   Servidor de desenvolvimento.

   Serve o app no Mac em http://localhost:8088 carregando os
   arquivos de src/ um a um (nada de bundle), entao basta
   recarregar a pagina para ver a mudanca.

   Tambem oferece /proxy?url=..., que repassa qualquer
   requisicao acrescentando os cabecalhos de CORS. Isso serve
   para dois fins: testar no navegador, e - se o servidor do
   seu provedor bloquear a TV - servir de modelo para o proxy
   de verdade descrito no README.
   ========================================================= */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const ROOT = path.resolve(__dirname, '..');
const FILES = require('./files');
const PORT = Number(process.env.PORT || 8088);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
};

function devPage() {
  const scripts = FILES.js
    .map((f) => `  <script src="/src/js/${f}?t=${Date.now()}"></script>`)
    .join('\n');
  const styles = FILES.css
    .map((f) => `  <link rel="stylesheet" href="/src/css/${f}?t=${Date.now()}">`)
    .join('\n');

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1920, initial-scale=1">
<title>Nebula (desenvolvimento)</title>
${styles}
<style>
  html,body{margin:0;padding:0;height:100%;background:#07080B;overflow:hidden}
  #shell-boot{position:fixed;inset:0;z-index:9000;display:flex;flex-direction:column;
    gap:16px;align-items:center;justify-content:center;background:#07080B;color:#8B93A1;
    font-family:Helvetica,Arial,sans-serif}
  #shell-boot .ring{width:48px;height:48px;border-radius:50%;
    border:4px solid rgba(255,255,255,.12);border-top-color:#7C5CFF;animation:sp .8s linear infinite}
  @keyframes sp{to{transform:rotate(360deg)}}
  #devbar{position:fixed;right:10px;bottom:8px;z-index:9999;background:rgba(20,24,32,.9);
    color:#7C5CFF;font:11px/1.4 monospace;padding:5px 10px;border-radius:6px;
    pointer-events:none;letter-spacing:.04em}
</style>
</head>
<body>
  <div id="root"></div>
  <div id="shell-boot"><div class="ring"></div><div class="msg">Iniciando…</div><div class="sub" id="shell-sub"></div></div>
  <div id="devbar">MODO DEV · setas = controle remoto · Backspace = voltar</div>

  <script src="/app/js/vendor/hls.min.js"></script>
  <script>
    /* Substituto do carregador real: em dev nao ha pacote nem atualizacao. */
    window.Updater = {
      loaded: { version: 'dev', source: 'dev', rolledBackFrom: null },
      confirmed: false,
      ready: function () {
        var b = document.getElementById('shell-boot');
        if (b && b.parentNode) b.parentNode.removeChild(b);
      },
      ok: function () { this.confirmed = true; this.ready(); },
      configured: function () { return false; },
      baseUrl: function () { return null; },
      check: function () { return Promise.reject(new Error('Atualização não existe no modo de desenvolvimento.')); },
      install: function () { return Promise.reject(new Error('Atualização não existe no modo de desenvolvimento.')); },
      rollback: function () { return false; },
      reset: function () {},
      reload: function () { location.reload(); },
      hasPrevious: function () { return false; }
    };
  </script>
${scripts}
</body>
</html>`;
}

function serveStatic(res, filePath) {
  fs.readFile(filePath, (err, buf) => {
    if (err) { res.writeHead(404); res.end('não encontrado'); return; }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(buf);
  });
}

function proxy(req, res, target) {
  let u;
  try { u = new URL(target); }
  catch (e) { res.writeHead(400); res.end('url inválida'); return; }

  const mod = u.protocol === 'https:' ? https : http;
  const opts = {
    method: req.method,
    headers: {
      'User-Agent': req.headers['user-agent'] || 'Nebula/1.0',
      'Accept': req.headers['accept'] || '*/*'
    }
  };
  if (req.headers['content-type']) opts.headers['Content-Type'] = req.headers['content-type'];
  ['apikey', 'authorization', 'prefer'].forEach((h) => {
    if (req.headers[h]) opts.headers[h] = req.headers[h];
  });

  const upstream = mod.request(u, opts, (up) => {
    const headers = Object.assign({}, up.headers);
    delete headers['content-security-policy'];
    delete headers['content-encoding-x'];
    headers['access-control-allow-origin'] = '*';
    res.writeHead(up.statusCode || 502, headers);
    up.pipe(res);
  });
  upstream.on('error', (e) => {
    res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8',
                         'access-control-allow-origin': '*' });
    res.end('proxy falhou: ' + e.message);
  });
  req.pipe(upstream);
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://localhost');

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'access-control-allow-origin': '*',
      'access-control-allow-methods': 'GET,POST,DELETE,PATCH,OPTIONS',
      'access-control-allow-headers': '*'
    });
    return res.end();
  }

  if (u.pathname === '/proxy') {
    const target = u.searchParams.get('url');
    if (!target) { res.writeHead(400); return res.end('faltou ?url='); }
    return proxy(req, res, target);
  }

  if (u.pathname === '/' || u.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store' });
    return res.end(devPage());
  }

  const rel = decodeURIComponent(u.pathname).replace(/^\/+/, '');
  const safe = path.normalize(path.join(ROOT, rel));
  if (!safe.startsWith(ROOT)) { res.writeHead(403); return res.end('nope'); }
  serveStatic(res, safe);

}).listen(PORT, () => {
  console.log(`Nebula em desenvolvimento:  http://localhost:${PORT}`);
  console.log(`Proxy de CORS:              http://localhost:${PORT}/proxy?url=...`);
});
