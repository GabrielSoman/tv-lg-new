/* =========================================================
   Proxy de CORS — plano B, só use se precisar.

   A TV instala o app localmente, e nesse caso o Chromium dela
   manda as requisições sem uma origem "de verdade". Servidores
   que não devolvem o cabeçalho Access-Control-Allow-Origin
   acabam recusando a leitura da resposta. O vídeo em si nunca
   passa por aqui (a tag <video> não sofre com CORS) — só o
   catálogo em JSON.

   COMO USAR (uns 5 minutos, de graça, sem cartão):
   1. Crie uma conta em https://dash.cloudflare.com
   2. Workers & Pages → Create → Worker → dê um nome
   3. Apague o código de exemplo e cole este arquivo inteiro
   4. Deploy. Você recebe um endereço tipo
        https://nebula-proxy.SEU-NOME.workers.dev
   5. Na TV: Ajustes → Lista de canais → campo "Proxy", cole
        https://nebula-proxy.SEU-NOME.workers.dev/?url=
      e aperte Reconectar.

   O ALLOW abaixo trava o proxy no seu servidor de IPTV, para
   que ninguém use seu worker como proxy aberto. Troque pelo
   domínio do seu provedor.
   ========================================================= */

const ALLOW = [
  // 'meuservidor.com',
  // '203.0.113.10',
];

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors() });
    }

    const target = url.searchParams.get('url');
    if (!target) {
      return new Response('Nebula proxy. Use ?url=<endereço>', {
        status: 400, headers: cors({ 'Content-Type': 'text/plain; charset=utf-8' })
      });
    }

    let t;
    try { t = new URL(target); }
    catch { return new Response('endereço inválido', { status: 400, headers: cors() }); }

    if (ALLOW.length && !ALLOW.some((h) => t.hostname === h || t.hostname.endsWith('.' + h))) {
      return new Response('esse host não está na lista permitida do worker',
                          { status: 403, headers: cors() });
    }

    const upstream = await fetch(t.toString(), {
      method: request.method,
      headers: passthrough(request.headers),
      body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
      redirect: 'follow'
    });

    const headers = cors({
      'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    });
    return new Response(upstream.body, { status: upstream.status, headers });
  }
};

function cors(extra = {}) {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,PATCH,OPTIONS',
    'Access-Control-Allow-Headers': '*',
    ...extra
  };
}

function passthrough(h) {
  const out = new Headers();
  const keep = ['user-agent', 'accept', 'content-type', 'apikey', 'authorization', 'prefer', 'range'];
  for (const k of keep) if (h.get(k)) out.set(k, h.get(k));
  if (!out.get('user-agent')) out.set('user-agent', 'Nebula/1.0');
  return out;
}
