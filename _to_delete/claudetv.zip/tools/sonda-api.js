#!/usr/bin/env node
/* =========================================================
   SONDA DA API E DO EPG
   =========================================================
   O diagnóstico mostrou que o `player_api.php` devolve
   HTTP 200 com zero byte. Isso pode significar duas coisas
   muito diferentes:

     · o provedor desligou a API (comum, para evitar cópia
       de lista) — e aí tudo vem do M3U de 81 MB;
     · ou ela existe em outro caminho, outra porta, outro
       método, e a gente ganha categorias prontas, estrutura
       de séries e EPG de graça.

   Esta sonda testa 12 variações em uns 20 segundos e também
   descobre se existe guia de programação (EPG), que é o que
   você pediu para o ao vivo.

       node tools/sonda-api.js

   O resultado não contém usuário, senha nem endereço.
   ========================================================= */

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const zlib = require('zlib');
const { URL } = require('url');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'relatorio-api.md');
const L = [];
const diz = (s = '') => { L.push(s); console.log(s); };

const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'nebula.config.json'), 'utf8'));
const SRC = new URL((cfg.source || {}).url);
const USER = SRC.searchParams.get('username') || SRC.searchParams.get('user');
const PASS = SRC.searchParams.get('password') || SRC.searchParams.get('pass');
const HOST = SRC.hostname;
const PORTA = SRC.port || (SRC.protocol === 'https:' ? '443' : '80');

function mascarar(t) {
  if (!t) return t;
  let s = String(t);
  [USER, PASS, HOST].forEach((v) => { if (v) s = s.split(v).join('«oculto»'); });
  return s;
}

function pedir(url, { metodo = 'GET', corpo = null, agente = 'VLC/3.0.20 LibVLC/3.0.20', ms = 12000 } = {}) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(url); } catch { return resolve({ erro: 'url inválida' }); }
    const mod = u.protocol === 'https:' ? https : http;
    const opts = {
      method: metodo,
      rejectUnauthorized: false,
      headers: {
        'User-Agent': agente, 'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate'
      }
    };
    if (corpo) {
      opts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
      opts.headers['Content-Length'] = Buffer.byteLength(corpo);
    }
    const req = mod.request(u, opts, (res) => {
      const enc = (res.headers['content-encoding'] || '').toLowerCase();
      let f = res;
      if (enc === 'gzip') f = res.pipe(zlib.createGunzip());
      else if (enc === 'deflate') f = res.pipe(zlib.createInflate());
      let d = '', n = 0, pronto = false;
      const fim = () => {
        if (pronto) return; pronto = true;
        resolve({ status: res.statusCode, tipo: res.headers['content-type'] || '',
                  bytes: n, corpo: d });
      };
      f.on('data', (c) => { n += c.length; if (d.length < 4000) d += c.toString('utf8'); });
      f.on('end', fim); f.on('error', fim);
      res.on('aborted', fim); res.on('error', fim);
    });
    req.on('error', (e) => resolve({ erro: e.message }));
    req.setTimeout(ms, () => { req.destroy(); resolve({ erro: 'tempo esgotado' }); });
    if (corpo) req.write(corpo);
    req.end();
  });
}

function julgar(r) {
  if (!r || r.erro) return { ok: false, nota: 'erro: ' + (r ? r.erro : '?') };
  if (r.bytes === 0) return { ok: false, nota: `HTTP ${r.status}, resposta vazia` };
  let j = null;
  try { j = JSON.parse(r.corpo); } catch {}
  if (j && (j.user_info || Array.isArray(j))) {
    return { ok: true, json: j,
             nota: `HTTP ${r.status}, ${r.bytes} bytes, **JSON válido**` +
                   (j.user_info ? ' com `user_info`' : ` (lista de ${j.length})`) };
  }
  return { ok: false, nota: `HTTP ${r.status}, \`${r.tipo}\`, ${r.bytes} bytes, não é o JSON esperado` +
                            (r.corpo ? ` — começa com \`${mascarar(r.corpo.slice(0, 90)).replace(/\s+/g, ' ')}\`` : '') };
}

const cred = `username=${encodeURIComponent(USER)}&password=${encodeURIComponent(PASS)}`;

(async () => {
  diz('# Sonda da API e do EPG');
  diz('');
  diz('> Sem credenciais, sem endereços.');
  diz('');
  diz(`Servidor: porta \`${PORTA}\`, protocolo \`${SRC.protocol.replace(':', '')}\`.`);
  diz('');

  const base = `${SRC.protocol}//${SRC.host}`;
  const testes = [
    ['player_api.php — chamada básica',        `${base}/player_api.php?${cred}`],
    ['player_api.php — pedindo categorias',    `${base}/player_api.php?${cred}&action=get_live_categories`],
    ['player_api.php — via POST',              `${base}/player_api.php`, { metodo: 'POST', corpo: cred }],
    ['panel_api.php',                          `${base}/panel_api.php?${cred}`],
    ['player_api.php em HTTPS',                `https://${HOST}/player_api.php?${cred}`],
    ['player_api.php na porta 8080',           `http://${HOST}:8080/player_api.php?${cred}`],
    ['player_api.php na porta 25461',          `http://${HOST}:25461/player_api.php?${cred}`],
    ['player_api.php na porta 8000',           `http://${HOST}:8000/player_api.php?${cred}`],
    ['player_api.php como navegador',          `${base}/player_api.php?${cred}`, { agente: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0 Safari/537.36' }],
    ['player_api.php sem User-Agent nenhum',   `${base}/player_api.php?${cred}`, { agente: '' }]
  ];

  diz('## A API existe em algum lugar?');
  diz('');
  let achou = null;
  for (const [nome, url, opts] of testes) {
    const r = await pedir(url, opts || {});
    const v = julgar(r);
    diz(`- **${nome}** → ${v.nota}`);
    if (v.ok && !achou) achou = { nome, json: v.json };
  }
  diz('');
  diz(achou
    ? `> **Achei: “${achou.nome}” funciona.** Isso muda o projeto para melhor — dá para usar categorias, estrutura de séries e EPG prontos.`
    : '> **A API está desligada mesmo.** Tudo tem de sair da lista M3U. É o cenário que já assumi na spec.');
  diz('');

  /* ---- EPG ---- */
  diz('## Existe guia de programação?');
  diz('');
  const epgs = [
    ['xmltv.php',            `${base}/xmltv.php?${cred}`],
    ['xmltv.php comprimido', `${base}/xmltv.php?${cred}&gzip=1`],
    ['epg.php',              `${base}/epg.php?${cred}`],
    ['guide.xml',            `${base}/guide.xml`],
    ['epg.xml.gz',           `${base}/epg.xml.gz`]
  ];
  let epgOk = false;
  for (const [nome, url] of epgs) {
    const r = await pedir(url, { ms: 20000 });
    if (!r || r.erro) { diz(`- **${nome}** → erro: ${r ? r.erro : '?'}`); continue; }
    const xml = /<tv[\s>]|<programme|<channel/i.test(r.corpo);
    diz(`- **${nome}** → HTTP ${r.status}, \`${r.tipo}\`, ${(r.bytes / 1048576).toFixed(1)} MB ` +
        `→ XMLTV de verdade: **${xml ? 'SIM' : 'não'}**`);
    if (xml && !epgOk) {
      epgOk = true;
      const canais = (r.corpo.match(/<channel\s/g) || []).length;
      const progs = (r.corpo.match(/<programme\s/g) || []).length;
      diz(`    - no começo do arquivo já vi ${canais} canais e ${progs} programas`);
      const m = r.corpo.match(/<programme[^>]*start="([^"]{8,})"/);
      if (m) diz(`    - formato de horário: \`${m[1]}\` (o sufixo diz o fuso)`);
    }
  }
  diz('');
  diz(epgOk
    ? '> **Tem EPG.** O mini-guia e a grade de programação são viáveis.'
    : '> **Não achei EPG.** Sem isso, o mini-guia e a grade ficam impossíveis por este provedor — e os itens correspondentes saem da spec.');
  diz('');

  /* ---- variantes da lista ---- */
  diz('## A lista tem versões mais leves?');
  diz('');
  diz('A lista completa tem 81 MB. Se o provedor aceitar filtro por tipo,');
  diz('dá para baixar só canais quando o usuário quer canais.');
  diz('');
  const variantes = [
    ['só canais (type=m3u_plus&output=hls)', `${base}/get.php?${cred}&type=m3u_plus&output=hls`],
    ['formato simples (type=m3u)',            `${base}/get.php?${cred}&type=m3u`],
    ['playlist de canais (type=live)',        `${base}/get.php?${cred}&type=live`],
    ['enigma2',                               `${base}/get.php?${cred}&type=enigma2`]
  ];
  for (const [nome, url] of variantes) {
    const r = await pedir(url, { ms: 15000 });
    if (!r || r.erro) { diz(`- **${nome}** → erro: ${r.erro}`); continue; }
    const m3u = /#EXTM3U|#EXTINF/.test(r.corpo);
    diz(`- **${nome}** → HTTP ${r.status}, \`${r.tipo}\`, li ${(r.bytes / 1048576).toFixed(1)} MB antes de cortar ` +
        `→ é M3U: **${m3u ? 'sim' : 'não'}**`);
  }
  diz('');

  fs.writeFileSync(OUT, L.join('\n') + '\n');
  console.log('\n---\nSalvo em relatorio-api.md');
})();
