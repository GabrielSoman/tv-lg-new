#!/usr/bin/env node
/* =========================================================
   Servidor Xtream falso, só para desenvolvimento e testes.
   Permite abrir o app e navegar por um catálogo inventado
   sem precisar da lista de verdade.

     node tools/mock-iptv.js
     e no app use:  http://localhost:9099/get.php?username=teste&password=123

   Nao tem nada a ver com o funcionamento na TV.
   ========================================================= */
const http = require('http');
const { URL } = require('url');
const zlib = require('zlib');

const PORT = Number(process.env.MOCK_PORT || 9099);

/* ---- Gera um PNG sólido de 2x3 (esticado pelo CSS) ---- */
function png(r, g, b) {
  const w = 12, h = 18;
  const raw = [];
  for (let y = 0; y < h; y++) {
    raw.push(0);
    for (let x = 0; x < w; x++) {
      const f = 0.55 + 0.45 * (y / h);
      raw.push(Math.round(r * f), Math.round(g * f), Math.round(b * f));
    }
  }
  const idat = zlib.deflateSync(Buffer.from(raw));
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body) >>> 0);
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', idat), chunk('IEND', Buffer.alloc(0))
  ]);
}
let crcTable = null;
function crc32(buf) {
  if (!crcTable) {
    crcTable = [];
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      crcTable[n] = c;
    }
  }
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return c ^ 0xFFFFFFFF;
}
const PALETTE = [[124,92,255],[78,168,255],[255,77,109],[56,211,159],[255,196,107],
                 [200,120,255],[90,200,220],[240,120,80]];

/* ---- Catálogo inventado ---- */
/* Nomes no mesmo estilo do provedor real, inclusive as categorias
   adultas — é isso que o filtro precisa pegar. */
const LIVE_CATS   = ['Canais |  Abertos', 'Canais | Esportes', 'Canais | HBO',
                     'Canais | Noticias', 'Canais | Infantil', 'Canais | Adultos +18'];
const VOD_CATS    = ['Filmes | Lançamentos 2026', 'Filmes | Ação', 'Filmes | Comedia',
                     'Filmes | Animação', 'Filmes | Adultos +18'];
const SERIES_CATS = ['Séries | Netflix', 'Séries | HBO MAX', 'Séries | Nacionais'];

/* Canais que existem em várias qualidades, e alguns em feeds de
   outras regiões — o caso que o agrupamento tem de separar. */
const BASES = [
  { nome: 'GLOBO SP',  cat: 0 }, { nome: 'SBT',       cat: 0 },
  { nome: 'RECORD',    cat: 0 }, { nome: 'BAND',      cat: 0 },
  { nome: 'ESPN 2',    cat: 1 }, { nome: 'SPORTV',    cat: 1 },
  { nome: 'COMBATE',   cat: 1 },
  { nome: 'HBO',       cat: 2 }, { nome: 'HBO+',      cat: 2 },
  { nome: 'HBO 2',     cat: 2 }, { nome: 'CINEMAX',   cat: 2 },
  { nome: 'GLOBONEWS', cat: 3 }, { nome: 'CNN BRASIL', cat: 3 },
  { nome: 'CARTOON NETWORK', cat: 4 }, { nome: 'DISCOVERY KIDS', cat: 4 }
];
const VARIANTES = ['UHD', 'FHD', 'HD', 'H265', 'SD'];
const REGIOES_MOCK = [
  { pre: '', peso: 1 },
  { pre: 'LAT | ', peso: 0.35 },
  { pre: 'USL- ', peso: 0.3 },
  { pre: 'PT- ', peso: 0.2 }
];

const WORDS = ['Aurora','Vertente','Última','Cidade','Silêncio','Origem','Fronteira','Tempestade',
               'Herança','Abismo','Farol','Corrida','Sombra','Verão','Retorno','Órbita','Ninho',
               'Quimera','Cinzas','Vento','Máquina','Deserto','Vigília','Império'];
function title(seed) {
  const a = WORDS[seed % WORDS.length];
  const b = WORDS[(seed * 7 + 3) % WORDS.length];
  return seed % 3 === 0 ? `${a} ${b}` : `A ${a} de ${b}`;
}
const img = (i) => `http://localhost:${PORT}/img/${i % PALETTE.length}.png`;

function liveStreams(catId) {
  const out = [];
  let id = 1000, num = 1;
  BASES.forEach((b, bi) => {
    REGIOES_MOCK.forEach((r, ri) => {
      /* nem todo canal existe em toda região */
      if (ri > 0 && (bi % 3) !== (ri % 3)) return;
      VARIANTES.forEach((q, qi) => {
        if (ri > 0 && qi > 2) return;          /* feeds estrangeiros têm menos variantes */
        out.push({
          num: num++,
          name: `${r.pre}${b.nome} ${q}`,
          stream_type: 'live',
          stream_id: id++,
          stream_icon: img(bi),
          epg_channel_id: `ch.${b.nome.toLowerCase().replace(/\W+/g, '')}`,
          added: String(1700000000 + bi * 1000),
          category_id: String(b.cat + 1),
          tv_archive: 0, tv_archive_duration: 0
        });
      });
    });
  });
  /* uns canais adultos, para o filtro ter o que esconder */
  for (let k = 0; k < 6; k++) {
    out.push({
      num: num++, name: `CANAL ADULTO ${k + 1} HD`, stream_type: 'live',
      stream_id: id++, stream_icon: img(k), epg_channel_id: '',
      added: '1700000000', category_id: '6', tv_archive: 0, tv_archive_duration: 0
    });
  }
  return catId ? out.filter((c) => c.category_id === String(catId)) : out;
}
const FRANQUIA = ['John Wick', 'John Wick 2', 'John Wick 3', 'John Wick 4',
                 'Vingadores', 'Vingadores Ultimato', 'Vingadores Guerra Infinita'];

function vodStreams(catId) {
  if (String(catId) === '1') {
    /* categoria com franquias, para testar "relacionados" */
    return FRANQUIA.map((n, i) => ({
      stream_id: 5000 + i, name: n, stream_icon: img(i), category_id: '1',
      rating: '7.5', year: String(2018 + i), added: String(1700000000 + i * 900),
      container_extension: 'mp4', episode_run_time: '110'
    }));
  }
  const n = catId ? 60 : 300;
  const base = Number(catId || 9) * 2000;
  return Array.from({ length: n }, (_, i) => ({
    stream_id: base + i, name: title(base + i), stream_icon: img(base + i),
    category_id: catId || String((i % VOD_CATS.length) + 1),
    rating: (5 + (i % 5) + 0.5).toFixed(1),
    year: String(2015 + (i % 11)),
    added: String(1700000000 + (n - i) * 8640),
    container_extension: 'mp4',
    episode_run_time: String(80 + (i % 60))
  }));
}
function seriesList(catId) {
  const n = catId ? 30 : 90;
  const base = Number(catId || 8) * 3000;
  return Array.from({ length: n }, (_, i) => ({
    series_id: base + i, name: title(base + i), cover: img(base + i),
    category_id: catId || String((i % SERIES_CATS.length) + 1),
    rating: (6 + (i % 4)).toFixed(1),
    releaseDate: `${2018 + (i % 8)}-03-14`,
    last_modified: String(1700000000 + (n - i) * 8640),
    plot: 'Uma história inventada só para testar a interface do aplicativo, com personagens que não existem.'
  }));
}
function seriesInfo(id) {
  const episodes = {};
  const seasons = 1 + (Number(id) % 3);
  for (let s = 1; s <= seasons; s++) {
    episodes[s] = Array.from({ length: 6 + (s % 4) }, (_, i) => ({
      id: `${id}${s}${i + 1}`, episode_num: i + 1,
      title: `${title(Number(id) + s * 10 + i)}`,
      container_extension: 'mp4',
      info: {
        movie_image: img(Number(id) + i),
        plot: 'Neste episódio, algo acontece e alguém precisa resolver antes que seja tarde.',
        duration_secs: 2400 + i * 60
      }
    }));
  }
  return {
    info: { name: title(Number(id)), cover: img(Number(id)),
            plot: 'Sinopse de teste da série inteira, com bastante texto para conferir se o corte do parágrafo está bonito na tela grande.',
            genre: 'Drama, Mistério', rating: '8.4', releaseDate: '2021-06-02' },
    episodes
  };
}

const cats = (names) => names.map((n, i) => ({ category_id: String(i + 1), category_name: n }));

http.createServer((req, res) => {
  /* Aceita POST com corpo urlencoded, como o painel de verdade. */
  if (req.method === 'POST') {
    let b = '';
    req.on('data', (c) => { b += c; });
    req.on('end', () => {
      const q = new URLSearchParams(b);
      req.url = req.url.split('?')[0] + '?' + q.toString();
      req.__eraPost = true;
      servir(req, res);
    });
    return;
  }
  servir(req, res);
}).listen(PORT, () => {
  console.log(`IPTV de mentira em http://localhost:${PORT}`);
  console.log(`Use no app: http://localhost:${PORT}/get.php?username=teste&password=123`);
});

function servir(req, res) {
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const send = (obj) => {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8',
                         'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(obj));
  };

  if (u.pathname.startsWith('/img/')) {
    const i = Number(u.pathname.split('/')[2].replace('.png', '')) || 0;
    const [r, g, b] = PALETTE[i % PALETTE.length];
    res.writeHead(200, { 'Content-Type': 'image/png', 'Access-Control-Allow-Origin': '*' });
    return res.end(png(r, g, b));
  }

  if (u.pathname === '/player_api.php') {
    /* Imita o defeito do painel real: por GET com Accept-Encoding
       ele devolve 200 com corpo vazio. É o que quebrava o app. */
    if (req.method !== 'POST' && !req.__eraPost) {
      res.writeHead(200, { 'Access-Control-Allow-Origin': '*' });
      return res.end();
    }
    const action = u.searchParams.get('action') || '';
    const cat = u.searchParams.get('category_id') || '';
    switch (action) {
      case '': return send({
        user_info: { auth: 1, status: 'Active', exp_date: '1790000000',
                     max_connections: '2', active_cons: '1' },
        server_info: { url: `localhost:${PORT}` }
      });
      case 'get_live_categories':   return send(cats(LIVE_CATS));
      case 'get_vod_categories':    return send(cats(VOD_CATS));
      case 'get_series_categories': return send(cats(SERIES_CATS));
      case 'get_live_streams':      return send(liveStreams(cat));   /* vazio = todos */
      case 'get_vod_streams':       return send(vodStreams(cat));
      case 'get_series':            return send(seriesList(cat));
      case 'get_series_info':       return send(seriesInfo(u.searchParams.get('series_id')));
      case 'get_vod_info':          return send({
        info: { plot: 'Sinopse de teste do filme, escrita para ocupar duas ou três linhas na tela.',
                genre: 'Ação, Aventura', cast: 'Fulana de Tal, Beltrano da Silva',
                director: 'Ciclana Pereira', rating: '7.8', releasedate: '2024-01-01',
                duration_secs: 6900, movie_image: img(3) },
        movie_data: { container_extension: 'mp4' }
      });
      default: return send([]);
    }
  }

  if (u.pathname === '/get.php') {
    res.writeHead(200, { 'Content-Type': 'audio/x-mpegurl', 'Access-Control-Allow-Origin': '*' });
    let out = '#EXTM3U\n';
    for (let i = 0; i < 50; i++) {
      out += `#EXTINF:-1 tvg-id="ch${i}" tvg-logo="${img(i)}" group-title="${LIVE_CATS[i % LIVE_CATS.length]}",BR| ${title(i)}\n`;
      out += `http://localhost:${PORT}/live/teste/123/${i}.m3u8\n`;
    }
    return res.end(out);
  }

  res.writeHead(404, { 'Access-Control-Allow-Origin': '*' });
  res.end('não encontrado');
}
