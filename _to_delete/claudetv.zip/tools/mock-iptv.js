#!/usr/bin/env node
/* =========================================================
   Servidor Xtream falso, só para desenvolvimento e testes.
   Permite abrir o app e navegar por um catálogo inventado
   sem precisar da lista de verdade.

     node tools/mock-iptv.js
     e no app use:  http://localhost:9099/get.php?username=teste&password=123

   Nao tem nada a ver com o funcionamento na TV.
   ========================================================= */
const http = require('http');
const { URL } = require('url');
const zlib = require('zlib');

const PORT = Number(process.env.MOCK_PORT || 9099);

/* ---- Gera um PNG sólido de 2x3 (esticado pelo CSS) ---- */
function png(r, g, b) {
  const w = 12, h = 18;
  const raw = [];
  for (let y = 0; y < h; y++) {
    raw.push(0);
    for (let x = 0; x < w; x++) {
      const f = 0.55 + 0.45 * (y / h);
      raw.push(Math.round(r * f), Math.round(g * f), Math.round(b * f));
    }
  }
  const idat = zlib.deflateSync(Buffer.from(raw));
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body) >>> 0);
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', idat), chunk('IEND', Buffer.alloc(0))
  ]);
}
let crcTable = null;
function crc32(buf) {
  if (!crcTable) {
    crcTable = [];
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      crcTable[n] = c;
    }
  }
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return c ^ 0xFFFFFFFF;
}
const PALETTE = [[124,92,255],[78,168,255],[255,77,109],[56,211,159],[255,196,107],
                 [200,120,255],[90,200,220],[240,120,80]];

/* ---- Catálogo inventado ---- */
const LIVE_CATS   = ['Abertos', 'Esportes', 'Filmes & Séries', 'Notícias', 'Infantil'];
const VOD_CATS    = ['Lançamentos 2026', 'Ação', 'Comédia', 'Animação', 'Documentários'];
const SERIES_CATS = ['Séries Netflix', 'Séries HBO', 'Nacionais'];

const WORDS = ['Aurora','Vertente','Última','Cidade','Silêncio','Origem','Fronteira','Tempestade',
               'Herança','Abismo','Farol','Corrida','Sombra','Verão','Retorno','Órbita','Ninho',
               'Quimera','Cinzas','Vento','Máquina','Deserto','Vigília','Império'];
function title(seed) {
  const a = WORDS[seed % WORDS.length];
  const b = WORDS[(seed * 7 + 3) % WORDS.length];
  return seed % 3 === 0 ? `${a} ${b}` : `A ${a} de ${b}`;
}
const img = (i) => `http://localhost:${PORT}/img/${i % PALETTE.length}.png`;

function liveStreams(catId) {
  const n = 40;
  const base = Number(catId) * 1000;
  return Array.from({ length: n }, (_, i) => ({
    stream_id: base + i, name: `BR| ${title(base + i).toUpperCase()} FHD`,
    stream_icon: img(base + i), category_id: catId,
    epg_channel_id: `ch${base + i}`
  }));
}
function vodStreams(catId) {
  const n = catId ? 60 : 300;
  const base = Number(catId || 9) * 2000;
  return Array.from({ length: n }, (_, i) => ({
    stream_id: base + i, name: title(base + i), stream_icon: img(base + i),
    category_id: catId || String((i % VOD_CATS.length) + 1),
    rating: (5 + (i % 5) + 0.5).toFixed(1),
    year: String(2015 + (i % 11)),
    added: String(1700000000 + (n - i) * 8640),
    container_extension: 'mp4',
    episode_run_time: String(80 + (i % 60))
  }));
}
function seriesList(catId) {
  const n = catId ? 30 : 90;
  const base = Number(catId || 8) * 3000;
  return Array.from({ length: n }, (_, i) => ({
    series_id: base + i, name: title(base + i), cover: img(base + i),
    category_id: catId || String((i % SERIES_CATS.length) + 1),
    rating: (6 + (i % 4)).toFixed(1),
    releaseDate: `${2018 + (i % 8)}-03-14`,
    last_modified: String(1700000000 + (n - i) * 8640),
    plot: 'Uma história inventada só para testar a interface do aplicativo, com personagens que não existem.'
  }));
}
function seriesInfo(id) {
  const episodes = {};
  const seasons = 1 + (Number(id) % 3);
  for (let s = 1; s <= seasons; s++) {
    episodes[s] = Array.from({ length: 6 + (s % 4) }, (_, i) => ({
      id: `${id}${s}${i + 1}`, episode_num: i + 1,
      title: `${title(Number(id) + s * 10 + i)}`,
      container_extension: 'mp4',
      info: {
        movie_image: img(Number(id) + i),
        plot: 'Neste episódio, algo acontece e alguém precisa resolver antes que seja tarde.',
        duration_secs: 2400 + i * 60
      }
    }));
  }
  return {
    info: { name: title(Number(id)), cover: img(Number(id)),
            plot: 'Sinopse de teste da série inteira, com bastante texto para conferir se o corte do parágrafo está bonito na tela grande.',
            genre: 'Drama, Mistério', rating: '8.4', releaseDate: '2021-06-02' },
    episodes
  };
}

const cats = (names) => names.map((n, i) => ({ category_id: String(i + 1), category_name: n }));

http.createServer((req, res) => {
  /* Aceita POST com corpo urlencoded, como o painel de verdade. */
  if (req.method === 'POST') {
    let b = '';
    req.on('data', (c) => { b += c; });
    req.on('end', () => {
      const q = new URLSearchParams(b);
      req.url = req.url.split('?')[0] + '?' + q.toString();
      req.method = 'GET';
      servir(req, res);
    });
    return;
  }
  servir(req, res);
}).listen(PORT, () => {
  console.log(`IPTV de mentira em http://localhost:${PORT}`);
  console.log(`Use no app: http://localhost:${PORT}/get.php?username=teste&password=123`);
});

function servir(req, res) {
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const send = (obj) => {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8',
                         'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(obj));
  };

  if (u.pathname.startsWith('/img/')) {
    const i = Number(u.pathname.split('/')[2].replace('.png', '')) || 0;
    const [r, g, b] = PALETTE[i % PALETTE.length];
    res.writeHead(200, { 'Content-Type': 'image/png', 'Access-Control-Allow-Origin': '*' });
    return res.end(png(r, g, b));
  }

  if (u.pathname === '/player_api.php') {
    const action = u.searchParams.get('action') || '';
    const cat = u.searchParams.get('category_id') || '';
    switch (action) {
      case '': return send({
        user_info: { auth: 1, status: 'Active', exp_date: '1790000000',
                     max_connections: '2', active_cons: '1' },
        server_info: { url: `localhost:${PORT}` }
      });
      case 'get_live_categories':   return send(cats(LIVE_CATS));
      case 'get_vod_categories':    return send(cats(VOD_CATS));
      case 'get_series_categories': return send(cats(SERIES_CATS));
      case 'get_live_streams':      return send(liveStreams(cat || '1'));
      case 'get_vod_streams':       return send(vodStreams(cat));
      case 'get_series':            return send(seriesList(cat));
      case 'get_series_info':       return send(seriesInfo(u.searchParams.get('series_id')));
      case 'get_vod_info':          return send({
        info: { plot: 'Sinopse de teste do filme, escrita para ocupar duas ou três linhas na tela.',
                genre: 'Ação, Aventura', cast: 'Fulana de Tal, Beltrano da Silva',
                director: 'Ciclana Pereira', rating: '7.8', releasedate: '2024-01-01',
                duration_secs: 6900, movie_image: img(3) },
        movie_data: { container_extension: 'mp4' }
      });
      default: return send([]);
    }
  }

  if (u.pathname === '/get.php') {
    res.writeHead(200, { 'Content-Type': 'audio/x-mpegurl', 'Access-Control-Allow-Origin': '*' });
    let out = '#EXTM3U\n';
    for (let i = 0; i < 50; i++) {
      out += `#EXTINF:-1 tvg-id="ch${i}" tvg-logo="${img(i)}" group-title="${LIVE_CATS[i % LIVE_CATS.length]}",BR| ${title(i)}\n`;
      out += `http://localhost:${PORT}/live/teste/123/${i}.m3u8\n`;
    }
    return res.end(out);
  }

  res.writeHead(404, { 'Access-Control-Allow-Origin': '*' });
  res.end('não encontrado');
}
