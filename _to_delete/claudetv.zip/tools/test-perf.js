#!/usr/bin/env node
/* =========================================================
   MEDIÇÃO DE PERFORMANCE
   =========================================================
   Roda a MESMA sequência de 60 movimentos de foco com as duas
   políticas visuais — a antiga e a nova — com a CPU limitada
   para se aproximar de uma TV, e compara a duração dos quadros.

   Precisa do servidor de desenvolvimento:
       npm run dev
   e então:
       node tools/test-perf.js
   ========================================================= */
const { chromium } = require('playwright');

const BASE = (process.env.APP_URL || 'http://localhost:8088') + '/tools/perf-fixture.html';
/* 4× é a aproximação razoável de uma TV moderna. FREIO=6 roda o
   teste de estresse; FREIO=1 mostra o teto da máquina. */
const FREIO = Number(process.env.FREIO || 4);
const MOVIMENTOS = 60;
const PAUSA = 160;                              // ms entre teclas, como no controle

const ORCAMENTO = { p95: 17.5, travadosPct: 5 };   // 17,5 = um quadro + ruído

async function medir(politica) {
  const browser = await chromium.launch({ args: ['--force-device-scale-factor=1'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const cdp = await page.context().newCDPSession(page);

  await page.goto(`${BASE}?css=${politica}`, { waitUntil: 'load' });
  await page.waitForTimeout(900);                       // deixa assentar

  await cdp.send('Emulation.setCPUThrottlingRate', { rate: FREIO });
  await page.waitForTimeout(400);
  await page.evaluate(() => window.zerarMedicao());

  /* percorre fileiras e cards, que é onde o usuário reclamou */
  const passos = [];
  for (let i = 0; i < MOVIMENTOS; i++) {
    passos.push(i % 10 === 9 ? 'ArrowDown' : 'ArrowRight');
  }
  for (const k of passos) {
    await page.keyboard.press(k);
    await page.waitForTimeout(PAUSA);
  }
  await page.waitForTimeout(500);

  const m = await page.evaluate(() => window.medicao());
  const camadas = await cdp.send('Memory.getDOMCounters').catch(() => null);
  const nos = await page.evaluate(() => document.querySelectorAll('*').length);

  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 1 }).catch(() => {});
  await browser.close();
  return Object.assign({ nos, docs: camadas ? camadas.documents : null }, m);
}

function linha(rot, a, b, unidade, menorMelhor) {
  const dif = b === 0 ? 0 : ((a - b) / a) * 100;
  const seta = menorMelhor
    ? (b < a ? `−${dif.toFixed(0)}%` : (b > a ? `+${(-dif).toFixed(0)}%` : '=')) : '';
  console.log(
    '  ' + rot.padEnd(28) +
    String(a).padStart(9) + unidade.padEnd(4) +
    String(b).padStart(9) + unidade.padEnd(4) +
    seta.padStart(8)
  );
}

(async () => {
  console.log(`\nCPU limitada em ${FREIO}×, ${MOVIMENTOS} movimentos de foco, ` +
              `${PAUSA}ms entre teclas.\n`);

  process.stdout.write('  medindo a política antiga… ');
  const antigo = await medir('antigo');
  console.log('pronto');

  process.stdout.write('  medindo a política nova…   ');
  const novo = await medir('novo');
  console.log('pronto\n');

  console.log('  ' + 'métrica'.padEnd(28) + 'antes'.padStart(9) + '    ' +
              'depois'.padStart(9) + '    ' + 'variação'.padStart(8));
  console.log('  ' + '-'.repeat(62));
  linha('quadro típico (p50)', antigo.p50, novo.p50, 'ms', true);
  linha('quadro ruim (p95)', antigo.p95, novo.p95, 'ms', true);
  linha('pior quadro', antigo.pior, novo.pior, 'ms', true);
  const pct = (m, campo) => +((m[campo] / m.quadros) * 100).toFixed(0);
  linha('quadros lentos (>16,7ms)', pct(antigo, 'acima16'), pct(novo, 'acima16'), '%', true);
  linha('quadros travados (>33,3ms)', pct(antigo, 'acima33'), pct(novo, 'acima33'), '%', true);
  linha('quadros desenhados', antigo.quadros, novo.quadros, '', false);
  linha('nós no DOM', antigo.nos, novo.nos, '', true);

  console.log('\n  A contagem bruta engana: com a folha antiga o navegador');
  console.log('  desenhava MENOS quadros porque cada um demorava mais. Por isso');
  console.log('  a comparação é em porcentagem dos quadros de cada execução.');

  const travados = +((novo.acima33 / novo.quadros) * 100).toFixed(0);
  const travadosAntes = +((antigo.acima33 / antigo.quadros) * 100).toFixed(0);

  console.log('\n  Aferição');
  console.log('  ' + '-'.repeat(62));
  console.log(`  A CPU está ${FREIO}× mais lenta. É um teste de estresse, não a`);
  console.log('  velocidade real da TV — o número que vale mesmo sai do');
  console.log('  inspetor apontado para o aparelho (npm run log).');
  console.log('');
  console.log('  Sobre o p95: entre execuções ele salta entre 16,8 e 33,3ms.');
  console.log('  Não é variação real, é quantização: com 160ms entre teclas a');
  console.log('  maioria dos quadros é ociosa (16,7ms) e só os da transição');
  console.log('  estouram, então o percentil 95 cai ora de um lado ora do outro');
  console.log('  da fronteira. Por isso o critério é a PROPORÇÃO de quadros');
  console.log('  travados, que se manteve estável em todas as execuções.');
  console.log('');
  console.log(`    quadros travados antes ... ${travadosAntes}%`);
  console.log(`    quadros travados depois .. ${travados}%   (teto aceito: ${ORCAMENTO.travadosPct}%)`);

  console.log('');
  if (travados > ORCAMENTO.travadosPct) {
    console.log('  Ainda acima do teto.');
    process.exit(2);
  }
  console.log('  Dentro do teto. Camada 2 cumprida.');
})().catch((e) => { console.error('a medição quebrou:', e); process.exit(1); });
