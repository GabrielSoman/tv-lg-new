#!/usr/bin/env node
/* =========================================================
   Quantos canais têm catch-up, e de quantos dias.
   Roda em uns 3 segundos:

       node tools/catchup.js

   Também testa se a URL de reprodução do arquivo funciona.
   ========================================================= */
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const { URL } = require('url');

const ROOT = path.resolve(__dirname, '..');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'nebula.config.json'), 'utf8'));
const SRC = new URL(cfg.source.url);
const U = SRC.searchParams.get('username'), P = SRC.searchParams.get('password');
const BASE = `${SRC.protocol}//${SRC.host}`;

function req(url, { metodo = 'GET', corpo = null, so = 0 } = {}) {
  return new Promise((res) => {
    const u = new URL(url);
    const mod = u.protocol === 'https:' ? https : http;
    const h = { 'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept': '*/*' };
    if (corpo) {
      h['Content-Type'] = 'application/x-www-form-urlencoded';
      h['Content-Length'] = Buffer.byteLength(corpo);
    }
    const r = mod.request(u, { method: metodo, headers: h }, (s) => {
      let d = '', n = 0, fim = false;
      const acaba = () => { if (!fim) { fim = true; res({ status: s.statusCode, tipo: s.headers['content-type'] || '', bytes: n, corpo: d }); } };
      s.on('data', (c) => { n += c.length; if (!so || d.length < so) d += c; if (so && d.length >= so) { r.destroy(); acaba(); } });
      s.on('end', acaba); s.on('error', acaba);
    });
    r.on('error', (e) => res({ erro: e.message }));
    r.setTimeout(20000, () => { r.destroy(); res({ erro: 'tempo esgotado' }); });
    if (corpo) r.write(corpo);
    r.end();
  });
}

(async () => {
  const corpo = `username=${encodeURIComponent(U)}&password=${encodeURIComponent(P)}&action=get_live_streams`;
  const r = await req(`${BASE}/player_api.php`, { metodo: 'POST', corpo });
  let lista;
  try { lista = JSON.parse(r.corpo); } catch { console.log('não veio JSON'); return; }

  const com = lista.filter((c) => Number(c.tv_archive) > 0);
  const dias = {};
  com.forEach((c) => { const d = String(c.tv_archive_duration || '?'); dias[d] = (dias[d] || 0) + 1; });

  console.log('');
  console.log(`Canais no total .............. ${lista.length}`);
  console.log(`Com catch-up (tv_archive) .... ${com.length}  (${((com.length / lista.length) * 100).toFixed(0)}%)`);
  console.log('');
  console.log('Dias de gravação disponíveis:');
  Object.entries(dias).sort((a, b) => Number(b[0]) - Number(a[0]))
    .forEach(([d, n]) => console.log(`   ${String(d).padStart(3)} dia(s) → ${n} canais`));
  console.log('');
  console.log('Exemplos:');
  com.slice(0, 8).forEach((c) => console.log(`   ${c.name}  —  ${c.tv_archive_duration} dia(s)`));

  /* Testa a URL de timeshift: 30 minutos atrás, num canal com arquivo. */
  if (com[0]) {
    const agora = new Date(Date.now() - 30 * 60000);
    const p = (n) => String(n).padStart(2, '0');
    const inicio = `${agora.getFullYear()}-${p(agora.getMonth() + 1)}-${p(agora.getDate())}:` +
                   `${p(agora.getHours())}-${p(agora.getMinutes())}`;
    const formatos = [
      ['timeshift no caminho', `${BASE}/timeshift/${encodeURIComponent(U)}/${encodeURIComponent(P)}/60/${inicio}/${com[0].stream_id}.ts`],
      ['streaming/timeshift.php', `${BASE}/streaming/timeshift.php?username=${encodeURIComponent(U)}&password=${encodeURIComponent(P)}&stream=${com[0].stream_id}&start=${inicio}&duration=60`]
    ];
    console.log('');
    console.log(`Testando reprodução do arquivo de "${com[0].name}", 30 min atrás:`);
    for (const [nome, url] of formatos) {
      const t = await req(url, { so: 2000 });
      console.log(`   ${nome} → ` + (t.erro ? 'erro: ' + t.erro
        : `HTTP ${t.status}, ${t.tipo || 'sem tipo'}, ${t.bytes} bytes ` +
          (t.status === 200 && t.bytes > 0 ? '→ FUNCIONA' : '→ não')));
    }
  }
  console.log('');
})();
