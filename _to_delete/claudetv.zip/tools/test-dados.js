#!/usr/bin/env node
/* =========================================================
   TESTE DA CAMADA DE DADOS
   =========================================================
   Exercita o cliente da API e o catálogo contra um painel de
   mentira que imita os defeitos do painel real — inclusive o
   principal: por GET ele responde 200 com corpo vazio.

   Precisa dos dois servidores:
       node tools/mock-iptv.js &
       npm run dev
   e então:
       node tools/test-dados.js
   ========================================================= */
const { chromium } = require('playwright');

const APP  = (process.env.APP_URL  || 'http://localhost:8088') + '/tools/dados-fixture.html';
const MOCK = process.env.MOCK_URL || 'http://localhost:9099';
const LISTA = MOCK + '/get.php?username=teste&password=123&type=m3u_plus';

let page;
const falhas = [];
let n = 0;

function ok(rot, real, esperado) {
  n++;
  const bate = JSON.stringify(real) === JSON.stringify(esperado);
  console.log(`  ${bate ? 'ok   ' : 'FALHA'}  ${rot}` +
    (bate ? '' : `\n           esperado: ${JSON.stringify(esperado)}\n           veio:     ${JSON.stringify(real)}`));
  if (!bate) falhas.push(rot);
}
const ev = (fn, arg) => page.evaluate(fn, arg);

(async () => {
  const browser = await chromium.launch();
  page = await browser.newPage();
  page.on('pageerror', (e) => falhas.push('erro de JS: ' + e.message));
  await page.goto(APP, { waitUntil: 'load' });
  await ev(() => window.limpar());

  /* =======================================================
     1. A API só responde a POST
     ======================================================= */
  console.log('\n1) O painel só responde a POST');
  const porGet = await ev((base) => new Promise((res) => {
    const x = new XMLHttpRequest();
    x.open('GET', base + '/player_api.php?username=teste&password=123', true);
    x.onload = () => res({ status: x.status, tamanho: x.responseText.length });
    x.onerror = () => res({ erro: true });
    x.send();
  }), MOCK);
  ok('por GET vem 200 com corpo vazio (o defeito que nos enganou)',
     porGet, { status: 200, tamanho: 0 });

  /* =======================================================
     2. Conexão
     ======================================================= */
  console.log('\n2) Conexão');
  const conta = await ev((url) => Catalog.conectar(url).then(
    (c) => ({ conexoes: c.conexoes, status: c.status }),
    (e) => ({ erro: e.message })), LISTA);
  ok('conecta pela API', conta.status, 'Active');
  ok('lê o limite de conexões simultâneas', conta.conexoes, 2);

  const creds = await ev(() => ({
    modo: Store.get('source.mode'),
    usuario: Store.get('source.username')
  }));
  ok('deduz o usuário da URL da lista', creds.usuario, 'teste');
  ok('grava o modo xtream', creds.modo, 'xtream');

  /* =======================================================
     3. Categorias e conteúdo adulto
     ======================================================= */
  console.log('\n3) Categorias e conteúdo adulto');
  const cats = await ev(() => Catalog.categorias('live').then((c) => c.map((x) => x.nome)));
  ok('lê as categorias de canais', cats.length, 6);
  const adultas = await ev(() =>
    Catalog.categorias('live').then((c) => c.filter((x) => Catalog.ehAdulta(x.nome)).map((x) => x.nome)));
  ok('reconhece "Canais | Adultos +18"', adultas, ['Canais | Adultos +18']);

  const comAdulto = await ev(() => Catalog.canais().then((c) => c.length));
  await ev(() => { Store.set('adulto.ocultar', true); return Catalog.limparCache(); });
  const semAdulto = await ev(() => Catalog.categorias('live')
    .then(() => Catalog.canais()).then((c) => c.length));
  ok('com a ocultação ligada, os canais adultos somem', semAdulto < comAdulto, true);
  const sobrouAdulto = await ev(() => Catalog.canais()
    .then((c) => c.filter((g) => /adulto/i.test(g.title)).length));
  ok('e não sobra nenhum', sobrouAdulto, 0);
  await ev(() => { Store.set('adulto.ocultar', false); return Catalog.limparCache(); });

  /* =======================================================
     4. Agrupamento de qualidade — o coração da escada
     ======================================================= */
  console.log('\n4) Agrupamento de qualidade');
  const canais = await ev(() => Catalog.categorias('live').then(() => Catalog.canais()));
  const crus = await ev((base) => new Promise((res) => {
    const x = new XMLHttpRequest();
    x.open('POST', base + '/player_api.php', true);
    x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    x.onload = () => res(JSON.parse(x.responseText).length);
    x.send('username=teste&password=123&action=get_live_streams');
  }), MOCK);
  ok('a lista crua tem mais entradas que a agrupada', crus > canais.length, true);
  console.log(`         ${crus} entradas cruas → ${canais.length} canais lógicos`);

  const globo = canais.filter((c) => /GLOBO SP/i.test(c.chave) && !c.regiao)[0];
  ok('o canal brasileiro juntou suas 5 qualidades', globo.variantes.length, 5);
  ok('e a melhor delas vem primeiro', globo.variantes[0].qualidade, 'UHD');
  ok('a ordem da escada é decrescente',
     globo.variantes.map((v) => v.qualidade), ['UHD', 'FHD', 'HD', 'H265', 'SD']);

  const globoPT = canais.filter((c) => /GLOBO SP/i.test(c.chave) && c.regiao === 'PT')[0];
  ok('o feed de Portugal virou um canal SEPARADO', !!globoPT, true);
  ok('e não foi misturado com o brasileiro', globoPT.chave !== globo.chave, true);

  const hbo = canais.filter((c) => c.chave === 'HBO')[0];
  const hboMais = canais.filter((c) => c.chave === 'HBO+')[0];
  ok('HBO e HBO+ continuam sendo canais diferentes',
     !!(hbo && hboMais && hbo.chave !== hboMais.chave), true);

  /* a escada exclui 4K por padrão */
  const escada = await ev(() => Catalog.categorias('live').then(() => Catalog.canais())
    .then((c) => {
      const g = c.filter((x) => x.chave === 'GLOBO SP')[0];
      return Catalog.escada(g).map((v) => v.qualidade);
    }));
  ok('a escada automática deixa o 4K/UHD de fora', escada.indexOf('UHD'), -1);
  ok('e mantém as demais em ordem', escada, ['FHD', 'HD', 'H265', 'SD']);

  /* =======================================================
     5. Filmes, séries e cache
     ======================================================= */
  console.log('\n5) Filmes, séries e cache');
  const filmes = await ev(() => Catalog.itens('movie', '1').then((f) => f.length));
  ok('carrega uma categoria de filmes', filmes > 0, true);

  const t0 = Date.now();
  await ev(() => Catalog.itens('movie', '1'));
  ok('a segunda leitura vem do cache (instantânea)', Date.now() - t0 < 120, true);

  const serie = await ev(() => Catalog.categorias('series')
    .then(() => Catalog.itens('series', '1'))
    .then((s) => Catalog.serie(s[0].seriesId))
    .then((d) => ({
      temporadas: d.temporadas.length,
      episodios: d.temporadas.reduce((a, t) => a + t.episodios.length, 0),
      comDuracao: d.temporadas.reduce((a, t) =>
        a + t.episodios.filter((e) => e.duracao > 0).length, 0),
      primeiro: d.temporadas[0].episodios[0].temporada + 'x' + d.temporadas[0].episodios[0].episodio
    })));
  ok('a série vem com temporadas', serie.temporadas > 0, true);
  ok('e com episódios', serie.episodios > 0, true);
  ok('todos os episódios informam duração', serie.comDuracao, serie.episodios);
  ok('o primeiro episódio é o 1x1', serie.primeiro, '1x1');

  /* =======================================================
     6. Busca e relacionados
     ======================================================= */
  console.log('\n6) Busca e relacionados');
  const achados = await ev(() => Catalog.indice()
    .then((ix) => Catalog.buscar('globo', ix).map((x) => x.title)));
  ok('a busca acha canais', achados.length > 0, true);

  const semAcentoOk = await ev(() => Catalog.indice()
    .then((ix) => Catalog.buscar('acao', ix).length >= 0));
  ok('busca sem acento não quebra', semAcentoOk, true);

  const rel = await ev(() => Catalog.itens('movie', '1').then((f) => {
    const alvo = f.filter((x) => x.title === 'John Wick')[0];
    return Catalog.relacionados(alvo, f, 5).map((x) => x.title);
  }));
  ok('relacionados de "John Wick" trazem a franquia',
     rel.filter((t) => /John Wick/.test(t)).length >= 3, true);
  ok('e a franquia vem antes de qualquer outra coisa',
     /John Wick/.test(rel[0]), true);
  console.log('         ' + rel.join(' · '));

  await browser.close();

  console.log('\n=============================');
  console.log(`${n - falhas.length}/${n} verificações passaram.`);
  if (falhas.length) {
    console.log('\nFALHOU em:');
    falhas.forEach((f) => console.log('  • ' + f));
    process.exit(1);
  }
  console.log('Camada de dados: API por POST, agrupamento e filtros conferem.');
})().catch((e) => { console.error('o teste quebrou:', e); process.exit(1); });
