# Nebula — Especificação de Experiência

> Companheiro do `SPEC.md`. Aquele documento trata de *como* o app deve ser
> construído (navegação, performance, arquitetura). Este trata de *o que* o app
> deve fazer. Foi o passo que faltou, e a ausência dele é a razão de o app ter
> virado uma casca bonita sem produto dentro.

---

## 1. O que está quebrado hoje, e por quê

### 1.1 Episódio termina e não vai para o próximo

A fila existe e está correta (`player.js:202-217`, `views.js:751-763`). O
problema é a **condição que dispara**: o código depende exclusivamente do
evento `ended` do `<video>`.

Com VOD de painel Xtream isso não é confiável. As URLs de filme e episódio são
`/movie/user/pass/ID.<container>` e `/series/user/pass/ID.<container>`, com
container tipicamente `mp4` ou **`mkv`**. Em MKV o Chromium frequentemente não
determina a duração (`duration` vem `Infinity` ou `NaN`) e, ao chegar no fim,
o elemento **estagna** em vez de emitir `ended` — o servidor simplesmente para
de enviar bytes. Sem `ended`, `onEnded` nunca roda, e o app "para tudo".

**Decisão:** o fim de conteúdo deixa de ser um evento e passa a ser um
**estado derivado**, com três detectores independentes:

1. `ended` disparou;
2. `duration` é finita e `currentTime >= duration - 1.5s`;
3. `readyState` estagnado por mais de 8s com `currentTime` sem avançar **e**
   já passado de 90% do conteúdo (quando há duração conhecida).

Qualquer um dos três conclui o item. E, independentemente disso, o card de
próximo episódio aparece **antes** do fim (ver 5), então o usuário nunca fica
olhando para uma tela parada.

### 1.2 O player não tem menu

Hoje, apertar para baixo durante a reprodução dá seek de 5 minutos. Não há
como pausar por menu, reiniciar, trocar de episódio, ver a lista de episódios
ou trocar idioma. Isso é uma lacuna de produto, não um detalhe.

O mapeamento correto é o canônico do Android TV, que é a única fonte
normativa pública para isso: **OK pausa; ←/→ retrocedem e avançam; ↑/↓ abrem
os controles sem interromper a reprodução.** São ações distintas e não devem
ser fundidas. A seção 4 especifica o menu inteiro.

### 1.3 O banco está subaproveitado — e favoritos morrem com o app

Hoje o Supabase guarda **só** posição de reprodução. E há um erro meu que
passou batido: **`favorites` vive apenas em `localStorage`** (`store.js:11`) e
nunca é sincronizado. Ou seja, a lista que você montar desaparece na primeira
reinstalação — exatamente o problema que o Supabase existia para resolver.

Além disso, canais ao vivo são gravados como progresso (`player.js:290-306`
grava com `kind:'live'`, posição 0). Você tem razão: ao vivo não tem posição
para retomar. O que faz sentido guardar de um canal é **frequência e recência
de uso**, que é outra coisa — e serve para ordenar os canais por hábito.

A seção 2 redesenha o modelo inteiro.

### 1.4 "Relacionados" não existe

Não há nenhuma implementação de conteúdo relacionado no código
(`grep -i relacionad|similar|recomend` em `views.js` retorna vazio). O que
você viu de aleatório eram as fileiras de categoria comuns. A seção 6 define
como fazer de verdade.

### 1.5 O hero parece errado

Duas causas somadas. A altura é `32rem` ≈ 548px, pouco mais de metade da tela
— fica atarracado. E a arte usada é o **pôster retrato** esticado numa caixa
larga, o que sempre vai parecer errado.

A correção da arte é fácil e eu não tinha notado: `get_vod_info` da Xtream
expõe **`backdrop_path`** (e `youtube_trailer`) além do `movie_image`. É essa
a imagem certa para o hero. Altura passa a **62vh**, com a arte sangrando até
a borda direita e um degradê horizontal cobrindo o terço esquerdo.

---

## 2. Modelo de dados

O princípio: **o banco é a memória do seu uso, não um cache de reprodução.**

### 2.1 Tabelas

| Tabela | Guarda | Por quê |
|---|---|---|
| `watch_progress` | Posição, duração, % assistido, `completed`, quando | Continuar assistindo, marcar capas, próximo episódio |
| `watch_history` | Evento de reprodução: item, quando, quanto tempo assistido | "Assistidos recentemente", estatísticas, ordenar por hábito |
| `favorites` | Item, tipo, quando foi adicionado, ordem manual | Sua lista — **sincronizada**, não mais só local |
| `channel_usage` | Canal, contador de aberturas, último uso | Ordenar canais por hábito, fileira "seus canais" |
| `series_state` | Série, temporada e episódio atuais, `completed` | Retomar série no episódio certo, marcar temporada inteira |
| `settings_sync` | Preferências que valem a pena sobreviver | Idioma preferido, autoplay, ordenação |

`watch_progress` deixa de aceitar `kind = 'live'`. Canal ao vivo escreve em
`channel_usage`, que é um upsert com incremento — barato e útil.

### 2.2 Estados de um item

Três estados derivados, calculados uma vez e guardados:

| Estado | Regra | Aparece como |
|---|---|---|
| `novo` | sem registro | nada |
| `assistindo` | `position ≥ 90s` e `< 92%` da duração | faixa de progresso na capa + fileira "Continuar assistindo" |
| `assistido` | `≥ 92%` da duração, ou marcado à mão | selo discreto de "visto" no canto da capa |

Ações manuais obrigatórias, porque toda detecção automática erra:
**"marcar como assistido"**, **"marcar como não assistido"** e **"remover de
continuar assistindo"**. A ausência dessa última é uma das reclamações mais
comuns em qualquer app de streaming.

### 2.3 Marcação nas capas

Você pediu, e é a forma mais barata de transformar o catálogo em memória:

- **Assistindo** — faixa de progresso na base da capa (já existe, mantém).
- **Assistido** — selo circular pequeno no canto superior direito, com um
  visto. Sem sombra, sem animação (regra P3 do `SPEC.md`).
- **Série em andamento** — o card da série mostra `T2 E5` no rodapé em vez do
  ano, quando há progresso.
- **Novo episódio disponível** — se a série tem episódio com data posterior ao
  último assistido, um ponto colorido. Depende de a lista trazer datas
  confiáveis; se não trouxer, o recurso simplesmente não aparece.

---

## 3. Privacidade e conteúdo adulto

Você definiu o requisito com precisão: *"nunca deve sugerir ou aparecer como
visitado"*. Isso só é satisfeito se o filtro for **na origem dos dados**, não
na renderização.

### 3.1 Regras

1. **Detecção.** Categorias cujo nome, normalizado (minúsculas, sem acento),
   casa com `adulto`, `adultos`, `xxx`, `+18`, `18+`, `adult`, `porn`,
   `erotic` — com limites de palavra, para `hot` não pegar "hotel". Nada disso
   é padronizado entre provedores, então **a lista é editável** e cada
   categoria pode ser marcada ou desmarcada à mão nos Ajustes.
2. **Visível por padrão** (decisão 5). As categorias aparecem normalmente no
   catálogo, sem PIN. Existe um interruptor nos Ajustes que liga a ocultação
   total — e aí elas deixam de existir em todo lugar: menu, busca,
   relacionados, contadores.
3. **PIN de 4 dígitos**, opcional, só usado quando a ocultação está ligada.
   Teclado numérico na tela, navegável pelo direcional — o controle da LG pode
   não ter teclas numéricas.
4. **Nada é gravado. Nunca — visível ou não.** Esta regra vale
   independentemente do interruptor acima. Ao reproduzir conteúdo de categoria
   marcada como adulta, o app não escreve em `watch_progress`,
   `watch_history`, `channel_usage` nem `favorites`. Não é "gravar e
   esconder", não é "apagar depois" — é **não gravar**. Apagar depois deixa
   rastro; não gravar, não. Consequência aceita: esse conteúdo não tem
   "continuar assistindo" nem retomada de posição. É o preço, e é o que você
   pediu.
5. **Sessão curta**, quando a ocultação está ligada: o desbloqueio vale para a
   sessão atual e cai ao voltar para a home ou após 15 minutos sem uso.
6. **Sem rastro na interface.** Sair do modo não deixa item em "recentes",
   não altera "continuar assistindo", não muda nenhuma fileira.

### 3.2 Honestidade sobre o PIN

O PIN é guardado como hash com sal no `localStorage`, e apps empacotados no
webOS **não têm cookies** — então o armazenamento é inspecionável por quem
tiver acesso ao aparelho e às ferramentas de desenvolvedor. O PIN protege
contra alguém pegar o controle, não contra alguém com acesso técnico à TV.
A interface vai dizer isso em uma linha, em vez de fingir segurança que não
existe.

---

## 4. O player

### 4.1 Mapeamento de teclas

Segue o padrão canônico do Android TV, com adições para IPTV:

| Tecla | Sem OSD aberto | Com OSD aberto |
|---|---|---|
| OK | pausa / retoma | ativa o item em foco |
| ← / → | −10s / +10s (mantém o estado de play) | navega dentro da linha |
| ↑ / ↓ | **abre o OSD**, sem pausar | troca de linha do OSD |
| Voltar | sai do player | fecha um nível do OSD |
| CH +/− | próximo/anterior (episódio ou canal) | idem |
| ⏪ ⏩ | −5min / +5min | idem |
| ⏹ | sai | sai |

Segurar ←/→ entra em *scrubbing* contínuo com prévia da posição.
Auto-hide do OSD em 5 segundos de inatividade.

### 4.2 Estrutura do OSD

Duas linhas focáveis, com a barra de progresso entre elas — o modelo Leanback:

**Linha 1 — transporte:** reiniciar · −10s · play/pause · +10s · próximo

**Linha 2 — contexto:** Episódios · Áudio · Legendas · Info · Favoritar

Apertar ↓ a partir da linha 2 abre um **painel sobreposto** ao vídeo (nunca
uma tela nova): a grade de episódios da temporada, ou a lista de faixas. O
vídeo continua rodando atrás, escurecido.

O foco inicial é sempre o play/pause. ←/→ nunca pulam de linha; ↑/↓ nunca
pulam dentro da linha. É a mesma regra de regiões do `SPEC.md`, aplicada ao
player.

### 4.3 Áudio e legendas — o que é realmente possível

Preciso ser direto aqui, porque a expectativa importa mais que o recurso:

| Fonte | Trocar áudio | Legendas |
|---|---|---|
| Ao vivo `.m3u8` via hls.js | **Sim** (`hls.audioTracks`), se a playlist declarar as faixas | Sim, se houver WebVTT |
| Ao vivo `.ts` progressivo | **Não** — não é HLS, não há API de faixas | Não |
| VOD `.mp4` / `.mkv` direto | **Não** — o navegador não expõe faixas embutidas | Só legenda externa |

A razão é que `HTMLMediaElement.audioTracks` está **desabilitado por padrão em
todo Chromium**; só o Safari implementa. Não existe contorno no navegador.

**Consequências de projeto:** o app passa a **preferir `.m3u8` para ao vivo**
sempre (já é o padrão em `config.js`, agora vira regra); o botão de Áudio só
aparece quando há faixas de verdade, em vez de aparecer e não funcionar; e
para VOD, dublado versus legendado costuma vir do provedor como **itens
separados** no catálogo — então o app agrupa essas variantes pelo título
normalizado e oferece a escolha na tela de detalhe, que é onde ela realmente
existe.

O player nativo do webOS suporta legenda **apenas em WebVTT**, e multi-legenda
só em VoD. Não vou prometer SRT embutido.

---

## 5. Próximo episódio

- Aos **30 segundos do fim** (ou aos 97% quando não há duração), aparece um
  card no canto inferior direito com a capa do próximo episódio, título, e
  contagem regressiva de 10 segundos.
- **Qualquer direcional ou Voltar cancela** a contagem; o card fica, o
  episódio não troca sozinho.
- OK no card pula imediatamente.
- Se a contagem terminar, troca — e o progresso do episódio anterior é
  fechado como `assistido`.
- Existe um interruptor nos Ajustes para desligar o avanço automático,
  mantendo só o card. Paridade com o comportamento que a Netflix documenta.
- O próximo episódio é **pré-carregado** (`preload="metadata"` num elemento
  oculto) durante os últimos 60 segundos, para a troca ser instantânea.
- **Pular abertura** fica de fora por enquanto, e a razão é honesta: a API
  Xtream não fornece marcação de intro. Sem esse dado, qualquer botão seria
  chute. Fica como possibilidade futura via offset configurável por série.

---

## 6. Relacionados de verdade

Você descreveu o alvo com precisão: *nomes bem parecidos e coisas do mesmo
gênero*. O algoritmo, em ordem de peso:

1. **Franquia** — títulos normalizados que compartilham prefixo de pelo menos
   8 caracteres e 2 palavras ("john wick", "vingadores", "senhor dos aneis").
   Peso máximo. É o que faz o usuário sentir que o app entende o catálogo.
2. **Similaridade de título** — Jaro-Winkler sobre o título limpo, corte em
   0,82. Jaro-Winkler favorece prefixos iguais, que é exatamente o caso de
   franquia e sequência.
3. **Gênero em comum** — de `info.genre`, que a Xtream fornece. Interseção de
   gêneros, peso proporcional.
4. **Mesma categoria** do provedor — sinal fraco mas barato.
5. **Proximidade de ano** — desempate.

**Normalização é metade do trabalho.** Os títulos vêm sujos: `BR|`, `FHD`,
`4K`, `[L]`, `[DUB]`, `HEVC`, `H265`, ano entre parênteses. Sem limpar isso,
qualquer similaridade vira ruído. E a mesma normalização serve para **agrupar
duplicatas** — o mesmo filme em três qualidades vira um card com três opções,
em vez de três cards.

Sempre excluir do resultado: o próprio item, duplicatas de qualidade, e
qualquer coisa de categoria restrita.

**TMDB fica de fora, e explico.** Alguns painéis expõem `tmdb_id` em
`get_vod_info`, o que permitiria usar os endpoints de similares do TMDB — bem
melhores que qualquer heurística local. Mas o campo **não é garantido** (a
documentação de referência do XUI One nem o lista), e o tier gratuito do TMDB
é **exclusivamente não comercial**, exigindo atribuição visível. Para uso
pessoal seria aceitável, mas cria dependência de rede num app que já tem
problema de latência. **Decisão: heurística local como padrão**, com TMDB como
opção desligada por padrão nos Ajustes, para você ligar se quiser.

---

## 7. Ao vivo — o que falta e você não citou

Essa é a parte do app que hoje é a mais pobre, e é o uso mais frequente de
IPTV. Trago porque você pediu a lista maior.

- **Zapping por número.** Digitar `1` `2` `3` no controle vai direto ao canal
  123. É como se usa TV.
- **CH +/− entre canais da categoria atual**, não da lista inteira.
- **Último canal** — uma tecla que alterna entre os dois últimos. É o recurso
  mais usado de qualquer TV e não existe em quase nenhum app de IPTV.
- **Mini-EPG ao trocar de canal** — barra de 4 segundos com número, nome, o
  que está passando agora e o que vem depois.
- **Guia de programação** em grade, com carga só da janela visível.
- **Canais por hábito** — a fileira "seus canais" ordenada por `channel_usage`,
  que é o que torna 8 mil canais utilizáveis.
- **Agrupar duplicatas de qualidade** — "Globo FHD", "Globo HD", "Globo SD"
  viram um canal com escolha de qualidade.
- **Failover automático** — se o `.m3u8` falha, tentar `.ts` antes de mostrar
  erro. Já existe parcialmente; passa a ser regra, com aviso discreto.

---

## 7-A. Troca automática de qualidade do canal

Ideia sua, e é a melhor deste documento: quando o canal em alta resolução
engasga, o app cai sozinho para a versão mais leve e volta quando estabilizar.
Só que existem dois cenários tecnicamente muito diferentes, e **qual deles vale
para o seu provedor é o que o `tools/diagnostico-lista.js` vai dizer.**

### Cenário A — o `.m3u8` do canal já tem as qualidades dentro

Se a URL do canal devolve uma *playlist mestre* com várias linhas
`EXT-X-STREAM-INF`, então cada canal já carrega suas próprias resoluções, e o
hls.js faz a troca sozinho: adaptativa, contínua, **sem corte nenhum**. Nesse
caso não há nada a construir — só garantir que o app use o hls.js nesse canal
em vez do player nativo, e mostrar no menu qual qualidade está ativa.

É o melhor dos mundos, e é raro em painel de IPTV. O diagnóstico responde.

### Cenário B — cada resolução é um canal separado

É o caso comum: `GLOBO FHD`, `GLOBO HD`, `GLOBO SD` são três `stream_id`
diferentes. Aí a escada de qualidade é o app que monta.

**Montagem da escada.** Agrupar por nome normalizado (sem o prefixo de país,
sem os marcadores de qualidade) e ordenar as variantes:

```
4K / UHD / 2160p     ← fora da troca automática por padrão
FHD / 1080p
HD / 720p
SD / 480p
sem marcação         ← tratado como o degrau mais baixo conhecido
```

O 4K fica fora porque cair de 4K para SD é uma queda de qualidade grande
demais para o app decidir sozinho — e porque, como você notou, essas variantes
costumam ser streams à parte, muitas vezes de outro servidor. Vira um
interruptor nos Ajustes, desligado por padrão.

**Detecção de engasgo.** Só sinais que significam alguma coisa:

- eventos `waiting` do vídeo, contados numa janela deslizante;
- tempo acumulado parado dentro dessa janela;
- `currentTime` sem avançar enquanto não está pausado;
- tamanho do buffer, quando o hls.js está no comando.

**Regra de descida:** dois travamentos somando mais de 4 segundos dentro de
uma janela de 30 segundos → desce um degrau.

**Regra de subida:** depois de 60 segundos estável, tenta subir um degrau. Se
engasgar de novo em menos de 45 segundos, desce e **dobra a espera** (60s → 3
min → 10 min, com teto). Você falou em 30 segundos, e eu aumentaria para 60
com essa espera crescente pelo seguinte motivo: sem o recuo progressivo, um
canal cronicamente instável fica subindo e descendo a cada 30 segundos, e o
corte da troca incomoda mais que a qualidade menor. Tudo isso é configurável.

**Nunca troca automaticamente:** nos primeiros 8 segundos de um canal (é
buffer normal de abertura), nem mais de uma vez a cada 20 segundos.

### O que precisa ser dito com honestidade

**A troca tem corte.** Trocar de variante é carregar outra URL — 1 a 3
segundos de tela preta. Não é a troca invisível que a Netflix faz, porque
aquilo acontece *dentro* de um mesmo stream. Só o cenário A é invisível.

**E o corte é obrigatório por causa das conexões simultâneas.** Sua conta tem
um limite (`max_connections`, que o diagnóstico mostra). Se for 1 ou 2, o app
**não pode** abrir a variante nova antes de fechar a antiga — o servidor
recusaria por excesso de conexões. Ou seja: fecha, abre, e o corte é inevitável.
Se o limite for maior, dá para pré-carregar e reduzir bastante o corte.

**A interface avisa, sem atrapalhar.** Um aviso discreto — "conexão engasgou,
mudei para HD" — e o menu do player mostra a qualidade atual com a lista de
variantes. Escolha manual **fixa** a qualidade e desliga o automático até você
trocar de canal.

### O bônus que vem junto de graça

O mesmo agrupamento que monta a escada resolve outro problema: **as duplicatas
somem da lista**. Oito mil canais viram talvez dois mil e quinhentos canais
lógicos, cada um com suas qualidades por baixo. Isso sozinho torna a lista
navegável — e é o mesmo código.


---

## 8. Atualização automática

Você pediu, e faz sentido agora que o mecanismo provou que se recupera de
versão quebrada:

- Verificação silenciosa na abertura e a cada 6 horas.
- Havendo versão nova, **baixa em segundo plano** e guarda.
- **Aplica na próxima abertura do app**, não no meio do uso. Trocar o código
  debaixo de alguém que está assistindo é ruim, mesmo que funcione.
- Se você estiver na home e ocioso por mais de 2 minutos, pode aplicar na
  hora — recarrega em silêncio.
- Interruptor nos Ajustes para voltar ao modo manual.
- A reversão automática continua sendo a rede de segurança.

---

## 9. Modo desenvolvedor: correção e possibilidade

**Primeiro, uma correção do que eu te disse.** Eu falei em 50 horas citando o
que a comunidade repete. O número atual, afirmado por **staff da LG no fórum
oficial**, é **1000 horas** — cerca de 41 dias. As 50 horas são valor
histórico de versões antigas do webOS, propagado por posts desatualizados.
Isso muda a conta: apertar EXTEND uma vez por mês já resolve, e sua ideia de
"a cada 15 dias" é folgada.

**Sobre o app se auto-renovar**, a pesquisa achou algo promissor e algo
frustrante.

O frustrante: o endpoint `ResetDevModeSession.dev` que eu tinha mencionado
**aparentemente não funciona mais** — retorna 200 OK e não renova o timer.
E ler o token da sessão de dentro do app é impossível sem root: apps webOS não
privilegiados não acessam `/var/luna/preferences/`.

O promissor: a própria LG documentou que a forma atual de estender pelo CLI é
`ares-launch com.palmdts.devmode -p extend=true`. E `ares-launch` é só um
invólucro de `luna://com.webos.applicationManager/launch`, que **é uma API
pública para apps**. Ou seja, em tese o Nebula poderia chamar:

```js
webOS.service.request('luna://com.webos.applicationManager', {
  method: 'launch',
  parameters: { id: 'com.palmdts.devmode', params: { extend: true } }
});
```

**Não está confirmado** que um app não privilegiado consegue lançar o app de
Modo Desenvolvedor — pode cair no erro de app privilegiado. Mas é barato
testar, e se funcionar resolve o problema inteiro de dentro da TV, sem
computador e sem root.

**Plano:** implementar como experimento na tela de Ajustes, com um botão
"Renovar Modo Desenvolvedor" que mostra o resultado bruto da chamada. Se
funcionar, vira automático — uma verificação por semana. Se não funcionar, o
botão sai e a resposta é honesta: precisa do Mac.

---

## 10. Backlog priorizado

Você pediu a lista maior. Está aqui, dividida por quanto muda o uso diário.

### P0 — sem isso o app não é usável

| # | Item |
|---|---|
| 1 | Regiões de navegação com borda que para (`SPEC.md` §3) |
| 2 | Rolagem com cálculo correto (`SPEC.md` §1.2) |
| 3 | Purga de performance (`SPEC.md` §4) |
| 4 | Fim de conteúdo por estado derivado, não por evento `ended` |
| 5 | OSD do player completo |
| 6 | Favoritos sincronizados no Supabase |
| 7 | `watch_progress` deixa de gravar ao vivo |
| 8 | Conteúdo adulto: detecção, PIN, e não gravar nada |
| 9 | Card de próximo episódio com contagem |
| 10 | Hero com `backdrop_path` e altura correta |

### P1 — o que faz parecer um app de verdade

| # | Item |
|---|---|
| 11 | Marcações nas capas: assistindo, assistido, `T2 E5` |
| 12 | Marcar como assistido / não assistido / remover de continuar |
| 13 | Relacionados por franquia + similaridade + gênero |
| 14 | Normalização de títulos e agrupamento de duplicatas de qualidade |
| 15 | Canais ordenados por hábito (`channel_usage`) |
| 16 | Último canal (tecla de alternância) |
| 17 | Zapping por número |
| 18 | Mini-EPG ao trocar de canal |
| 19 | Teclado próprio na busca — o teclado do sistema é ruim de usar |
| 20 | Busca com resultado por tipo (canais / filmes / séries em seções) |
| 21 | Ordenação e filtros: A-Z, ano, recém-adicionados, não assistidos |
| 22 | Atualização automática em segundo plano |
| 23 | Cache LRU de imagens decodificadas |
| 24 | Restaurar posição de rolagem e foco ao voltar |

### P2 — refinamento

| # | Item |
|---|---|
| 25 | Guia de programação (EPG em grade) |
| 26 | Agrupamento de dublado/legendado como variantes do mesmo título |
| 27 | Indicador de qualidade (4K/FHD/HD) extraído do nome |
| 28 | Trailer do YouTube na tela de detalhe (`youtube_trailer` vem da API) |
| 29 | Estatísticas: horas assistidas, série mais vista |
| 30 | Filtro "só não assistidos" dentro de uma série |
| 31 | Lista "assistir depois", separada de favoritos |
| 32 | Timer de desligamento |
| 33 | Modo economia: desliga animações e o fundo ambiente |
| 34 | Diagnóstico nos Ajustes: latência do servidor, fila do Supabase, versão |
| 35 | Renovação do Modo Desenvolvedor de dentro do app (experimento) |
| 36 | Segundo perfil |

---

## 11. Decisões tomadas

Registradas aqui para não se perderem na conversa.

| # | Decisão | Escolha |
|---|---|---|
| 1 | Menu lateral | **Sempre estreito, só ícones.** Rótulos aparecem por transparência quando o foco entra, sem mexer no layout |
| 2 | Fundo ambiente | **Removido.** Fundo escuro sólido. Era o culpado número 1 da queda de frames |
| 3 | Filmes/Séries | Mantém coluna de categorias + grade, agora com regiões de verdade |
| 4 | Autoplay do próximo episódio | **Ligado**, com contagem de 10 segundos e cancelamento por qualquer tecla |
| 5 | Conteúdo adulto | **Desbloqueado** — aparece no catálogo sem PIN. Mas **continua sem ser gravado**: nada de histórico, continuar assistindo, recentes ou relacionados. "Desbloqueado" é sobre visibilidade, não sobre registro |
| 6 | Uso da TV | Ao vivo e sob demanda **importam igual** — o bloco de ao vivo entra no P1, não fica para o fim |
| 7 | Recursos de ao vivo | Favoritos, últimos assistidos (sem adultos), **mini-EPG e guia completo**, e a **troca automática de qualidade** da seção 7-A |

O item 2 muda o `SPEC.md`: a técnica de canvas 32×48 descrita lá na seção 4
deixa de ser necessária. Fundo sólido, ponto final.


---

## 12. Correções depois do raio-x do provedor

Medições reais mudaram três coisas escritas acima.

**Cancelado: pré-carregar o próximo episódio.** A conta tem
`max_connections: 1` — uma transmissão por vez. Não dá para abrir o próximo
episódio nem a variante de qualidade antes de fechar o atual. Toda troca é
fechar-e-abrir, com corte. E encerrar a conexão explicitamente ao sair vira
requisito: uma conexão pendurada impede a próxima reprodução.

**Corrigido: o `.mkv` não é a causa do episódio não avançar.** A lista tem
287.269 arquivos `.mp4` e **um** `.mkv`. Minha hipótese não se aplica. A causa
real é que o app roda em modo M3U, e nesse modo `Catalog.seriesInfo()`
simplesmente rejeita — não existe série nenhuma, só 266 mil episódios soltos,
sem temporada e sem fila. Pela API o problema some: episódios vêm com
`season`, `episode_num` e `info.duration_secs`, e na amostra **16 de 16
tinham duração**.

**Melhor que o esperado: `tmdb_id` existe.** Está em `get_vod_info` e até em
`episode.info`. Relacionados via TMDB deixam de ser hipótese e viram opção
real — ainda assim desligada por padrão, pela licença não comercial e pela
latência.

**Cancelado: catch-up.** Eu tinha comemorado cedo demais. Os campos
`tv_archive` e `tv_archive_duration` existem na resposta da API, mas medindo
os 2.846 canais, **zero** têm arquivo — o recurso não está habilitado neste
plano. Sai da spec. Se um dia você trocar de plano, a checagem é uma linha:
qualquer canal com `tv_archive > 0`.

**Agrupamento de qualidade, versão correta:** separando região, são **433 de
1.910** canais com variantes, e a lista cai de 2.846 para 1.910 entradas. Os
prefixos `USL` (278), `LAT` (49), `PT` (38), `USA` (21), `IT` (14) e `ES` (2)
são feeds diferentes e nunca podem ser agrupados entre si.

## Fontes

**Player e UX de TV**
[Android TV — Playback controls](https://developer.android.com/training/tv/playback/controls) ·
[Android TV — Transport controls (Leanback)](https://developer.android.com/training/tv/playback/leanback/transport-controls) ·
[Android TV — Quality guidelines](https://developer.android.com/docs/quality-guidelines/tv-app-quality) ·
[Netflix — autoplay do próximo episódio](https://help.netflix.com/en/node/2102) ·
[Netflix — PIN de perfil](https://help.netflix.com/en/node/114277)

**Mídia e webOS**
[hls.js — API](https://github.com/video-dev/hls.js/blob/master/docs/API.md) ·
[caniuse — HTMLMediaElement.audioTracks](https://caniuse.com/mdn-api_htmlmediaelement_audiotracks) ·
[webOS — Streaming Protocol and DRM](https://webostv.developer.lge.com/develop/specifications/streaming-protocol-drm) ·
[webOS — Web API and Web Engine](https://webostv.developer.lge.com/develop/specifications/web-api-and-web-engine) ·
[Dolby OptiView — limitações do player webOS](https://optiview.dolby.com/resources/blog/playback/limitations-to-bringing-media-to-lgs-webos/) ·
[jellyfin-web #6363 — legendas embutidas no webOS](https://github.com/jellyfin/jellyfin-web/issues/6363)

**Xtream e metadados**
[XUI One — Player API](https://github.com/worldofiptvcom/xui-one-api-docs/blob/main/xtream-codes-player-api-documentation.md) ·
[go.xtream-codes — structs da API](https://pkg.go.dev/github.com/almo7aya/go.xtream-codes) ·
[m3u-editor #556 — tmdb_id nas respostas Xtream](https://github.com/m3ue/m3u-editor/issues/556) ·
[TMDB — recomendações](https://developer.themoviedb.org/reference/movie-recommendations) ·
[TMDB — limites de uso](https://developer.themoviedb.org/docs/rate-limiting) ·
[TMDB — atribuição e uso não comercial](https://developer.themoviedb.org/docs/faq) ·
[tuliprox — filtros e normalização de listas](https://github.com/euzu/tuliprox)

**Controle parental**
[Jellyfin — usuários e controle parental](https://jellyfin.org/docs/general/server/users/adding-managing-users/) ·
[jellyfin-meta #50 — remover de continuar assistindo](https://github.com/jellyfin/jellyfin-meta/discussions/50)

**Modo desenvolvedor**
[LG (staff) — extend via `ares-launch ... -p extend=true` e sessão de 1000h](https://forum.webostv.developer.lge.com/t/whats-the-way-to-extend-dev-time-with-webos-cli/28033) ·
[webOS — Application Manager API](https://webostv.developer.lge.com/develop/references/application-manager) ·
[dev-manager-desktop #256 — endpoint HTTP não renova mais](https://github.com/webosbrew/dev-manager-desktop/issues/256) ·
[webosbrew — Dev Mode](https://www.webosbrew.org/devmode/) ·
[webosbrew — Luna Service Bus e permissões](https://www.webosbrew.org/pages/luna-service-bus)

### Lacunas declaradas

Não confirmado e portanto não prometido: que um app não privilegiado consiga
lançar `com.palmdts.devmode` (precisa ser testado no aparelho); o layout exato
do OSD de Netflix, Disney+ e Prime Video, que não têm documentação pública de
design; a duração exata da contagem regressiva de autoplay desses apps; e a
presença de `tmdb_id` em qualquer painel Xtream específico — inclusive o seu,
que só saberemos consultando.
